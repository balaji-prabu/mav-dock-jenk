import org.junit.*;
import static org.junit.Assert.*;

public class PhoneValidatorJUnit {
	
	PhoneValidator validationObj ;

	@Before
	public void init() {
		validationObj = new PhoneValidator();
	}

	@Test
	public void testPhoneValidator_valid() {
		assertEquals(true, validationObj.validatePhoneNumber("+(91)9876543210"));
		assertEquals(true, validationObj.validatePhoneNumber("+(91)7876543210"));
		assertEquals(true, validationObj.validatePhoneNumber("+(91)8876543210"));
		assertEquals(true, validationObj.validatePhoneNumber("+(91)8012345679"));

	}

	@Test
	public void testPhoneValidator_invalid() {
		assertEquals(false, validationObj.validatePhoneNumber(""));
		assertEquals(false, validationObj.validatePhoneNumber("(91)8012345679"));
		assertEquals(false, validationObj.validatePhoneNumber("-(91)7801234567"));
		assertEquals(false, validationObj.validatePhoneNumber("+(90)8012345679"));
		assertEquals(false, validationObj.validatePhoneNumber("+(01)8012345679"));
		assertEquals(false, validationObj.validatePhoneNumber("+[91]7801234567"));
		assertEquals(false, validationObj.validatePhoneNumber("+(918012345679"));
		assertEquals(false, validationObj.validatePhoneNumber("+91)8012345679"));
		assertEquals(false, validationObj.validatePhoneNumber("+918012345679"));
		assertEquals(false, validationObj.validatePhoneNumber("+7801234567"));
		assertEquals(false, validationObj.validatePhoneNumber("+(91)6012345679"));
		assertEquals(false, validationObj.validatePhoneNumber("+(91)801234567"));
		assertEquals(false, validationObj.validatePhoneNumber("7801234567"));
		assertEquals(false, validationObj.validatePhoneNumber("6801234567"));
		assertEquals(false, validationObj.validatePhoneNumber("a7801234567"));
		assertEquals(false, validationObj.validatePhoneNumber("7801234567a"));
		

	}

	@After
	public void destroy() {
		validationObj = null;
	}
}
