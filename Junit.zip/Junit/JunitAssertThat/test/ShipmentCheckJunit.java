import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
//import static org.hamcrest.beans.HasPropertyWithValue.hasProperty;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.*;

import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ShipmentCheckJunit {
	
	static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	private ShipmentBO sh;
	List<Shipment> shipmentListObj = ShipmentDAO.shipmentList;
	
	@Before
	public void shipmentObjectCreation() {
		//fill code here.
		sh = new ShipmentBO();
	}
	
	@Test
	public void testFilterShipmentById() throws Exception {
		//fill code here.
		assertThat(null, is(sh.filterShipmentById(100, shipmentListObj)));
		assertThat(sh.filterShipmentById(45, shipmentListObj), hasProperty("name",equalTo("Laptop")));
	}
	
	@Test
	public void testDeleteShipmentDetails() throws Exception {
		//fill code here.
		sh.deleteShipmentDetails(shipmentListObj,11);
		assertThat(shipmentListObj, not(hasItem(hasProperty("name",equalTo("Air Cooler")))));
		sh.deleteShipmentDetails(shipmentListObj,111);
		assertThat(shipmentListObj, not(hasItem(hasProperty("id",equalTo("111")))));
	}
	
	@Test
	public void testInsertShipmentDetails() throws Exception {
		//fill code here.
		sh.insertShipmentDetails(shipmentListObj, "1000,Speaker,01/01/2015,150");
		assertThat(shipmentListObj, hasItem(hasProperty("name", is("Speaker"))));
	}
	
	
}
