import static org.hamcrest.CoreMatchers.*;

import java.text.SimpleDateFormat;
import java.util.*;
import org.junit.*;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsEqual;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ShipmentJunit {

	private ShipmentBO shipmentBO;

	@Before
	public void createObjectForEmailGenerator() {
		shipmentBO = new ShipmentBO();

	}

	@Test
	public void testEmailId() {
		assertThat(shipmentBO.generateEmailId("balaji prabu", new Date("10/10/1975")),is("balajiprabu1975@gmail.com"));
		assertThat(shipmentBO.generateEmailId("Virat Kohli", new Date("10/10/1997")),is("viratkohli1997@gmail.com"));
		assertThat(shipmentBO.generateEmailId("DARK Angel", new Date("10/10/1992")),is("darkangel1992@gmail.com"));
		assertThat(shipmentBO.generateEmailId("TOmMArvalo RiddLE", new Date("10/10/2011")),is("tommarvaloriddle2011@gmail.com"));
	}

}
