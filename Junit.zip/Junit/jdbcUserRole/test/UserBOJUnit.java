import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matcher;
import org.junit.Before;
import org.junit.Test;

public class UserBOJUnit {
	UserDAO userDAOIns = null;
	UserBO userBO = null;
	@Before
	public void setUp() {
		
		userDAOIns = new UserDAO();
		userBO = new UserBO();
		
		//fill the code
	}
	@Test
	public void testGetAllUsers() {
		//fill the code
		MockUserDAO mockUserDAO = new MockUserDAO();
		ArrayList<User> userList = userBO.getAllUsers(mockUserDAO);
		List<org.hamcrest.Matcher<? super User>> itemMatchers = new ArrayList<Matcher<? super User>>();
//		itemMatchers.add(hasProperty("name", hasProperty("name", equalTo("status2"))));
		itemMatchers.add(hasProperty("name", hasItems("Mathew", "Jane", "Jennifer", "Bula", "Rehaana", "Sinjana")));
//		System.out.println(userList);
//		assertThat(userList, itemMatchers);
		assertThat(userList, hasProperty("name", hasItems("Mathew", "Jane", "Jennifer", "Bula", "Rehaana", "Sinjana")));
	}
}


public class UserBOJUnit { 
    UserDAO userDAO; 
    UserBO userBO; 
    @Before 
    public void setUp() { 
        userDAO = new MockUserDAO(); 
        userBO = new UserBO(); 
    } 
    @Test 
    public void testGetAllUsers() { 
        ArrayList<User> users = userBO.getAllUsers(userDAO); 
        assertEquals(2, users.size()); 
        assertThat(users,containsInAnyOrder(hasProperty("id", is(1)),hasProperty("id", is(2)))); 
        assertThat(users,containsInAnyOrder(hasProperty("name", is("John")),hasProperty("name", is("Kyle")))); 
        assertEquals(124, users.get(0).getContact().getId().intValue()); 
        assertEquals(13, users.get(0).getRole().getId().intValue()); 
        assertEquals(134, users.get(1).getContact().getId().intValue()); 
        assertEquals(12, users.get(1).getRole().getId().intValue()); 
    } 
    private class MockUserDAO extends UserDAO { 
        public ArrayList<User> fetchAllUsers() { 
            User user1 = new User(1, "John", new Role(13, "Admin"),new Contact(124, "5th street", "Kansas", "Missouri")); 
            User user2 = new User(2, "Kyle", new Role(12, "Admin"),new Contact(134, "7th street", "Kansas", "Missouri")); 
            ArrayList<User> users = new ArrayList<User>(Arrays.asList(user1,user2)); 
            return users; 
        } 
    } 
} 


