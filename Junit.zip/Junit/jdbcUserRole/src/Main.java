import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		UserDAO userDAOIns = new UserDAO();
		UserBO userBO = new UserBO();
		ArrayList<User> userList = userBO.getAllUsers(userDAOIns);
		System.out.format("%-10s %-20s %-25s %-10s %-10s \n", "User", "Role",
				"Street", "City", "State");

		for (User userIns : userList) {

			System.out.format("%-10s %-20s %-25s %-10s %-10s \n", userIns
					.getName(), userIns.getRole().getName(), userIns
					.getContact().getStreet(), userIns.getContact().getCity(),
					userIns.getContact().getState());
		}
	}

}