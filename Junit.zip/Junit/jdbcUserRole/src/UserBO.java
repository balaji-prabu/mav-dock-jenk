import java.util.ArrayList;

public class UserBO {
	ArrayList<User> getAllUsers(UserDAO userDAOIns) {
		ArrayList<User> userList = userDAOIns.fetchAllUsers();
		return userList;
	}
}
