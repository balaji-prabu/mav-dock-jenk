import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class UserDAO {

	public ArrayList<User> fetchAllUsers() {

		ArrayList<User> userList = new ArrayList<User>();
		User user = null;
		try {
			Connection connection = DbConnection.getConnection();
			Statement statement1 = connection.createStatement();
			Statement statement2 = connection.createStatement();
			ResultSet rs1 = statement1
					.executeQuery("select * from user order by name asc");

			while (rs1.next()) {
				user = new User(rs1.getInt("id"), rs1.getString("name"),
						getRoleById(rs1.getInt("role_id")),
						getContactById(rs1.getInt("contact_id")));
				userList.add(user);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return userList;
	}

	public Role getRoleById(Integer roleId) {
		Role role = null;
		try {
			Connection connection = DbConnection.getConnection();
			Statement statement1 = connection.createStatement();
			Statement statement2 = connection.createStatement();
			ResultSet rs1 = statement1
					.executeQuery("select * from role where id =" + roleId);
			while (rs1.next()) {
				role = new Role(rs1.getInt("id"), rs1.getString("name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return role;
	}

	public Contact getContactById(Integer contactId) {
		Contact contact = null;
		try {
			Connection connection = DbConnection.getConnection();
			Statement statement1 = connection.createStatement();
			Statement statement2 = connection.createStatement();
			ResultSet rs1 = statement1
					.executeQuery("select * from contact where id ="
							+ contactId);
			while (rs1.next()) {
				contact = new Contact(rs1.getInt("id"),
						rs1.getString("street"), rs1.getString("city"),
						rs1.getString("state"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return contact;
	}

}
