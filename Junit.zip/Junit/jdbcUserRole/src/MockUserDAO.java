import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class MockUserDAO extends UserDAO {
	
	public ArrayList<User> fetchAllUsers() {

		ArrayList<User> userList = new ArrayList<User>();
		User user = null;
		try {
			Connection connection = DbConnection.getConnection();
			Statement statement1 = connection.createStatement();
			ResultSet rs1 = statement1
					.executeQuery("select * from user order by name asc");

			while (rs1.next()) {
				user = new User(rs1.getInt("id"), rs1.getString("name"),
						getRoleById(rs1.getInt("role_id")),
						getContactById(rs1.getInt("contact_id")));
				userList.add(user);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return userList;
	}
}
