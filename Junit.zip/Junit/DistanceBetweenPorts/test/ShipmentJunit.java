
import static org.junit.Assert.*;

import org.junit.*;



public class ShipmentJunit {
	private ShipmentBO shipmentBO;
	
	@Before
	public void createObjectForShipmentBO()
	{
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testfindNearestPort()
	{
		assertEquals(1, shipmentBO.findNearestPort(1, 2).intValue());
		assertEquals(-1, shipmentBO.findNearestPort(2, 1).intValue());
		assertEquals(0, shipmentBO.findNearestPort(2, 2).intValue());
	}
	
}
