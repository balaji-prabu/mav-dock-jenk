import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.*;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
public class CustomerJunit {
	
	CustomerBO customerBO;
	
	@Before
	public void init() {
		customerBO = new CustomerBO();
	}
	
	@Test
	public void testDuplicateCustomerId() {
		//fill the code
	}
	
	@After
	public void destroy() {
		customerBO = null;
	}
}
