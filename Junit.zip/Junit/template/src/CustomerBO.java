import java.util.*;

public class CustomerBO {
	
	public HashSet<Integer> findDuplicateCustomerId(Integer n,List<Integer> userId){
		HashSet<Integer> repeat = new HashSet<Integer>();
		for (int i = 0; i < n - 1; i++) 
			for (int j = i + 1; j < n; j++) 
				if (userId.get(i).equals(userId.get(j))) 
					repeat.add(userId.get(i));
		return repeat;
	}
}
