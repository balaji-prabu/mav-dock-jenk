import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class Main {

	public static void main(String[] args) throws IOException, InterruptedException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of purchases");
		Integer n =  Integer.parseInt(br.readLine());
		List<String> itemList = new ArrayList<String>();
		String item,searchItem;
		System.out.println("Enter the items purchased");
		for(int i=0;i<n;i++){
			item = br.readLine();
			itemList.add(item);
		}
		System.out.println("Number of items to search");
		n =  Integer.parseInt(br.readLine());
		List<ItemCount> threadList = new ArrayList<ItemCount>();
		for(int i=0;i<n;i++){
			searchItem = br.readLine();
			threadList.add(new ItemCount(searchItem, itemList));
		}
        for(ItemCount currentItem : threadList){
            currentItem.start();
        }
		//fill in your code here

		System.out.format("%-5s %-5s\n","Item Name","Count");
		for(ItemCount i:threadList){
			System.out.format("%-5s %-5s\n",i.itemName,i.count);
		}
		

	}

}
