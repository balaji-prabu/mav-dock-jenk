import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CompanyJunit {
	
	CompanyBO companyBO;
	@Before
	public void init(){
		//fill the code
		companyBO = new CompanyBO();
	}
	
	@Test
	public void testValidDiscount() {
		//fill the code
		assertEquals("Datex shipping offers discount", companyBO.hasDiscount(90, 400)); 
		assertEquals("Datex shipping offers discount", companyBO.hasDiscount(99, 499));
	}
	
	@Test
	public void testInvalidDiscount() {
		//fill the code
		assertEquals("Datex shipping offers no discount", companyBO.hasDiscount(100, 300));
		assertEquals("Datex shipping offers no discount", companyBO.hasDiscount(140, 499));
		assertEquals("Datex shipping offers no discount", companyBO.hasDiscount(99, 499));
		
		assertEquals("Datex shipping offers no discount", companyBO.hasDiscount(140, 599));

	}
}
