import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
public class CustomerBO {
	public int getCustomerCount(ArrayList<Integer> customer, int val) {
		 int cust = 0;
		 Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		 for(int i=0;i<customer.size();i++) {
			 map.put(customer.get(i),Collections.frequency(customer, customer.get(i)));
		 }
		 for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
			 Integer value = entry.getValue();
			 if(value>val) {
				 cust++;
			 }
		 }
		 return cust;
	 }
}