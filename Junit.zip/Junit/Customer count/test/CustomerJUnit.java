import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class CustomerJUnit {
	CustomerBO customerBO;
	ArrayList<Integer> customer;
	@Before
	public void createObjectForCustomerBO() {
		customerBO = new CustomerBO();
	}
	@Test
	public void testCustomerCount() {
		customer = new ArrayList<Integer>();
		customer.add(1);
		customer.add(1);
		customer.add(1);
		customer.add(1);
		customer.add(2);
		customer.add(2);
		customer.add(2);
		customer.add(3);
		customer.add(3);
		customer.add(3);
		assertEquals(customerBO.getCustomerCount(customer, 2),3);
		assertEquals(customerBO.getCustomerCount(customer, 3),1);
		assertEquals(customerBO.getCustomerCount(customer, 10),0);
	}
}
