import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJunit {
	ShipmentEntityBO seObj ;
	static List<ShipmentEntity> shipmentList = new ArrayList<ShipmentEntity>();
	@Before
	public void ShipmentEntityObjectCreation() {
		//fill code here.
		seObj = new ShipmentEntityBO();
		shipmentList.add(new ShipmentEntity(101,"Hill gosling","2365265667", 8000L, "Agent"));
		shipmentList.add(new ShipmentEntity(105,"Madhu","982387402", 20000L, "Shipper"));
	}

	@Test
	public void testShipmentByShipper() {
		//fill code here.
		List<ShipmentEntity> tempList = seObj.filterShipmentByType(shipmentList,"Shipper");
		assertThat(tempList, containsInAnyOrder(hasProperty("id",equalTo(1)),hasProperty("id",equalTo(3)),hasProperty("id",equalTo(2)));
	}
	
	@Test
	public void testShipmentByAgent() {
		//fill code here.
		List<ShipmentEntity> tempList = seObj.filterShipmentByType(shipmentList,"Agent");
	}
	
}
