import java.util.*;


public class ItemCount extends Thread//fill in your code here
{
	String itemName;
	List<String> itemList;
	Integer count;
	
	public ItemCount(String itemName,List<String> itemList){
		this.itemName = itemName;
		this.count = 0;
		this.itemList=itemList;
	}
	
	public void run(){

		//fill in your code here
        for(String currentItem : this.itemList)    {
            if(this.itemName.equalsIgnoreCase(currentItem))
                this.count++;
        }


	}

}
