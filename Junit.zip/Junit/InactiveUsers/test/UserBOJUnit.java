import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.MatcherAssert.assertThat;
//import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.CoreMatchers.everyItem;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Before;
import org.junit.Test;

public class UserBOJUnit {
	UserBO userBOObj = null;

	@Before
	public void setUp() {
		//fill the code
		userBOObj = new UserBO();
	}

	@Test(expected = SQLException.class)
	public void testInActivate_withSQLException()
			throws InstantiationException, IllegalAccessException,
			ClassNotFoundException, SQLException {
		//fill the code
		MockUserDAO daoObj = new MockUserDAO();
		userBOObj.inActivate(1, daoObj);
	}

	@Test
	public void testInActivate() throws InstantiationException,
	IllegalAccessException, ClassNotFoundException, SQLException {
		UserDAO daoObj = new UserDAO();
		userBOObj.inActivate(5, daoObj);
		assertThat(userBOObj.fetchInactiveUsers(daoObj), everyItem(hasProperty("failed_attempts",greaterThanOrEqualTo(5))));
		//fill the code
	}

	@Test
	public void testFetchInActiveUsers() throws InstantiationException,
	IllegalAccessException, ClassNotFoundException, SQLException {

		//fill the code
		UserDAO daoObj = new UserDAO();
		userBOObj.fetchInactiveUsers(daoObj);
		assertThat(userBOObj.fetchInactiveUsers(daoObj), everyItem(hasProperty("deleted",equalTo(1))));

	}

	private class MockUserDAO extends UserDAO {
		//fill the code
		public void makeInActive(int failedAttempts) throws InstantiationException,
		IllegalAccessException, ClassNotFoundException, SQLException {
			Connection con = DbConnection.getConnection();
			Statement stmt = con.createStatement();

			if(failedAttempts < 2)
				throw new SQLException();
			
			String sql = "UPDATE user SET deleted = 1 where failed_attempts >="
					+ failedAttempts + "  ";
			stmt.executeUpdate(sql);

		}
	}
}
