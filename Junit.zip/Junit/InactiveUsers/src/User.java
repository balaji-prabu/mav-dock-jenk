
public class User {
    private Integer id;
	private String username;
	private String passsword;
	private String address;
    private Integer failedAttempts;
	private String mobile_number;
	private Integer deleted;
	
	public User(Integer id, String username, String passsword, String address,
			String mobile_number, Integer deleted) {
		super();
		this.id = id;
		this.username = username;
		this.passsword = passsword;
		this.address = address;
		this.mobile_number = mobile_number;
		this.deleted = deleted;
	}
	public Integer getId() {
		return id;
	}
        public Integer getFailedAttempts() {
		return failedAttempts;
	}
    
	public void setId(Integer id) {
		this.id = id;
	}
        public void setFailedAttempts(Integer setFailedAttempts) {
		this.failedAttempts = setFailedAttempts;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPasssword() {
		return passsword;
	}
	public void setPasssword(String passsword) {
		this.passsword = passsword;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}
	public Integer getDeleted() {
		return deleted;
	}
	public void setDeleted(Integer deleted) {
		this.deleted = deleted;
	}

}
