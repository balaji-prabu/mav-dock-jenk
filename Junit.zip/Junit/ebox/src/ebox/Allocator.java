package ebox;

import java.io.IOException;
import java.util.Scanner;

import cc.MaxMinUniq;

public class Allocator {

	public static void main(String[] args) {
//		string_lc_1();
		string_lc_2();
		try {
			MaxMinUniq.main(null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void string_lc_2() {
		System.out.println("Enter the file content:");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		System.out.println("Enter the virus keyword:");
		String pattern = scanner.nextLine();
		
		//A computer virus is a program or piece of code that is loaded %$ *(#@ )^^% onto your computer without your knowledge and runs against your wishes. Viruses can also replicate themselves. All computer viruses are man-made.
	}

	public static void string_lc_1(){
		System.out.println("Enter the xml input");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		System.out.format("%-15s %-15s\n","Tag Name","Length") ;
		
		String [] arrOfTags = input.split("}");
		for(int i=0; i<arrOfTags.length; i++){
			String currentTag = arrOfTags[i];
			if(!currentTag.contains("/")){
				currentTag.charAt(0);
				currentTag = currentTag.replace("{", "");
				System.out.format("%-15s %-15s\n", currentTag, currentTag.length());
			}
		}
		scanner.close();
		// {Shipment}{Item}{Price}100{/Price}{/Item}{Quantity}1{/Quantity}{/Shipment}		
	}

}