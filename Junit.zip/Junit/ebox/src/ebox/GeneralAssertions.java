package ebox;


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test; 
public class GeneralAssertions {    
	private Weather weather = new Weather(7);       
	@Test    
	public void showAssertTrue()    {        
		assertTrue("No Rainbow today", weather.isItSunnyToday() && weather.willItRainToday());       
		System.out.println("OK, test the rainbow stuff");
	}   
	@Test    
	public void showAssertFalse()    {
		assertFalse("Unsafe to drive", !(weather.isItFreezingToday() && weather.willItRainToday())); 
		System.out.println("Test the new vehicle");
	} 
}

