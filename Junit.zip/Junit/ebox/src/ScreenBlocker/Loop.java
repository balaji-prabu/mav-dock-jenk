package ScreenBlocker;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;

public class Loop {
    public static void main(String[] args) throws InterruptedException {
        // Gets the default toolkit.
        Toolkit toolkit = Toolkit.getDefaultToolkit();

        // Update the locking state for num lock button to true
        // will turn the num lock on.
        System.out.println();
        while(true){
        	toolkit.setLockingKeyState(KeyEvent.VK_NUM_LOCK, !toolkit.getLockingKeyState(KeyEvent.VK_NUM_LOCK));
        	Thread.sleep(10000L);
        }
    }
}