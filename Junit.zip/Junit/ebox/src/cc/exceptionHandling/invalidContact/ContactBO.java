package cc.exceptionHandling.invalidContact;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ContactBO {
	public ContactBO()
	{
		
	}
	private Pattern regexPattern;
	private Matcher regMatcher;
	public boolean validateContactDetails(Contact co) throws InvalidContactException 
	{
		boolean flag = true;
		if( 
				(co.getName() == null || co.getName().trim().length() == 0) ||
				(co.getSname() == null || co.getSname().trim().length() == 0) ||
				(co.getAdd() == null || co.getAdd().trim().length() == 0) ||
				(co.getCity() == null || co.getCity().trim().length() == 0) ||
				(co.getState() == null || co.getState().trim().length() == 0) ||
				(co.getPh() == null || co.getPh().trim().length() == 0) ||
				(co.getEmail() == null || co.getEmail().trim().length() == 0)
    		)
			throw new InvalidContactException("Make sure you entered all the fields");
		
		String phoneNumPattern = "\\d{10}";
		regexPattern = Pattern.compile(phoneNumPattern);
		regMatcher = regexPattern.matcher(co.getPh());
		
		if(!regMatcher.matches())
			throw new InvalidContactException("Invalid Phone Number");
		
		String emailPattern = ".*@.*\\..*";
		regexPattern = Pattern.compile(emailPattern);
		regMatcher = regexPattern.matcher(co.getEmail());
		
		if(!regMatcher.matches())
			throw new InvalidContactException("Invalid email");
		return flag;
	}
	
	
}



