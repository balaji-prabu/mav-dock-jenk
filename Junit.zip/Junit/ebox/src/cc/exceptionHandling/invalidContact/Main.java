package cc.exceptionHandling.invalidContact;

/*
 * Contact Validation
Roma is a Footwear shopping brand and its products is the talk of the town amongst teenagers lately. Surprisingly this brand is now available Online and the Company has come up with a Value added Service to its numerous wholesale and retail Customers, which is the Customers can now choose to buy their desired product through the exclusive shopping portal of Yocart. Before they could shop, the Customers should register with the Company using their valid contact details. However the Company was planning to implement an automated program that would perform the validity check on the Customer details.

The program should validate the details based on the below rules:
--> Street name, address, city and state should not be blank
--> Phone number should contain 10 digits
--> Email address should contain @ and . characters

If the contact details violate any of the rules then the program should throw an exception. Help them by coding the solution
 * 
 * 
 */
import java.io.*;
public class Main {
	public static void main(String arg[])throws IOException 
	{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("CONTACT DETAILS");

		System.out.println("Enter the name :");
		String name = br.readLine();
		
		System.out.println("Enter the street name :");
		String streetName = br.readLine();
		
		System.out.println("Enter the address :");
		String address = br.readLine();
		
		System.out.println("Enter the city :");
		String city = br.readLine();
		
		System.out.println("Enter the state :");
		String state = br.readLine();
		
		System.out.println("Enter the phone number :");
		String phoneNum = br.readLine();
		
		System.out.println("Enter the email id :");
		String email = br.readLine();
		
		Contact contactObj = new Contact(name, streetName, address, city, state, phoneNum, email);
		ContactBO obj = new ContactBO();
		try {
			if(obj.validateContactDetails(contactObj))
				System.out.println("Contact is valid");
		} catch (InvalidContactException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			System.out.println(e.toString());
		}
		
		

	}

}
