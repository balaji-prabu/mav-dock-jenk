package cc.exceptionHandling.invalidContact;

public class InvalidContactException extends Exception {
	public InvalidContactException (String errMsg){
		super(errMsg);
	}
}
