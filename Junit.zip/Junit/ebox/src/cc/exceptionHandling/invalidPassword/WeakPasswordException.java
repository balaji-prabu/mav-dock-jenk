package cc.exceptionHandling.invalidPassword;

public class WeakPasswordException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1806163711447948402L;

	WeakPasswordException(String err){
		super(err);
	}
    //fill code here

}