package cc.exceptionHandling.invalidPassword;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws Exception {
        
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter user name :");
        String uname = br.readLine();
        // fill code here.
        System.out.println("Enter password :");
        String pass = br.readLine();
        // fill code here.
        System.out.println("Enter address :");
        String address = br.readLine();
        // fill code here.
        User obj = new User(uname, pass, address);
        UserBO boObj = new UserBO();
        try{
        boObj.validatePassword(obj);
        } catch(WeakPasswordException e){
        	System.out.println(e.toString());
        }
		// fill code here.
    }
    
}


/*
 * Validate Password using Custom Exception

 John is the key authority of the Shipment Management System at Febex Logistics. His main role is to manage and control the Users who login through the Shipment System. An equally vital responsibility assigned to John is to validate Users passwords through the System and submits a report whether the passwords are strong or not. Now your task is, to write a piece of code to the System that will help John to validate the passwords using a custom exception. 

The exception is thrown when any of the following password validation condition fails:
It should be minimum of 8 characters.
It should contain atleast one digit.
It should contain atleast one special character (!@#$%).
Example :
mart@123 

Create a class named User with the following private member variables / attributes
    private String userName;
    private String password;
    private String address;
 Include appropriate getters and setters.
 Include 3 argument constructor with argument order User(String userName, String password, String address).

Create a UserBO class, and include the following methods 

No	Method Name	Method Description
1	void validatePassword(User user)	In this method, validate the password whether it is strong or weak. If it is weak then throw the exception WeakPasswordException.
In validatePassword method, that only throw exception to WeakPasswordException, when the any password condition fail(Problem Specification). 

Create custom exception class named as WeakPasswordException.
Create a constructor which accept the message as parameter like WeakPasswordException(String message).
Create a  Main  class to test the above classes. Invoke the  validatePassword  methods in the  UserBO , handle the exception, catch and throw the exception 

Input Format:
The first input consist of a string that corresponds to user name.
The second input consists of a string that corresponds to password.
The third input consists of a string that corresponds to address.
Refer sample input and output for formatting specifications.

Output Format :
Finally print the password status or exception.
Refer sample input and output for formatting specifications.

[Note :Strictly adhere to the object oriented specifications given as a part of the problem statement.Use the same class names, attribute names and method names.]

[All text in bold corresponds to input and the rest corresponds to output.]
Sample Input and Output 1:

Enter user name :
Martin
Enter password :
mart@123
Enter address :
California
Password is strong

Sample Input and Output 2:

Enter user name :
Mathew
Enter password :
mathew112
Enter address :
Los Angeles
WeakPasswordException: Password is weak 
 */
