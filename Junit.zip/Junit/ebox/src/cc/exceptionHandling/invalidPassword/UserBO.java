package cc.exceptionHandling.invalidPassword;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserBO {
	public void validatePassword(User user) throws WeakPasswordException{
		String password = user.getPassword();
		
		Matcher regNumMatcher;
		String numberPattern = ".*[\\d].*";
		Pattern regexPattern = Pattern.compile(numberPattern);
		regNumMatcher = regexPattern.matcher(password);
		
		if (password.length() < 8 || !regNumMatcher.matches() || 
				!(password.contains("!") || password.contains("@") || password.contains("#") || password.contains("$") || password.contains("%")  )
				)
			throw new WeakPasswordException("Password is weak ");
		else
			System.out.println("Password is strong");
	}
}
