package cc.exceptionHandling.invalidDate;

public class InvalidDateException extends Exception {
	InvalidDateException(String msg){
		super(msg);
	}
}
