package cc.exceptionHandling.invalidDate;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
public class Main {
	public static void main(String args[]) throws IOException, ParseException{
		SimpleDateFormat dateFormatObj = new SimpleDateFormat("dd/MM/yyyy");
		long daysBetween = ChronoUnit.MONTHS.between(LocalDate.parse("2016-08-31"),
			    LocalDate.parse("2016-11-30"));
		System.out.println(daysBetween);
		
		/*BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the cheque details");
		System.out.println("Enter the bank name :");
		String bankName = br.readLine();
		System.out.println("Enter the cheque number :");
		String cheqNum =  br.readLine();
		System.out.println("Enter the cheque date :");
		
		SimpleDateFormat dateFormatObj = new SimpleDateFormat("dd/MM/yyyy");
		Date dateObj = dateFormatObj.parse(br.readLine());
		
		
		Cheque cheqObj = new Cheque(bankName, cheqNum, dateObj);
		PaymentBO obj = new PaymentBO();
		try{
			if(obj.processPayment(cheqObj))
				System.out.println("Cheque is sent to clearing house");
		} catch(InvalidDateException e){
			System.out.println(e.toString());
		}*/
			
		
	}
}
