package cc.exceptionHandling.invalidDate;

import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class PaymentBO {
	public boolean processPayment(Cheque cheque) throws InvalidDateException{
		Date currentDate = new Date();
		int chequeMonth = cheque.getChequeDate().getYear() * 12 + cheque.getChequeDate().getMonth();
		int currentMonth = currentDate.getYear() *12 + currentDate.getMonth();
		int diff = currentMonth - chequeMonth + 1;
		if(diff > 3 ){
			throw new InvalidDateException("Cheque is valid only for three months");
		}
		return true;
	}
}
