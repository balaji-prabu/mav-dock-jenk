package cc.exceptionHandling.invalidDate;

import java.util.Date;

public class Cheque {
	private String bankName;
	private String chequeNumber;
	private Date chequeDate;
	
	public Cheque(String bankName, String chequeNum, Date chequeDate){
		this.bankName = bankName;
		this.chequeNumber = chequeNum;
		this.chequeDate = chequeDate;
	}
	
	public void setBankName(String bankName){
		this.bankName = bankName;
	}
	
	public String getBankName(){
		return this.bankName;
	}
	
	public void setChequeNumber(String chequeNumber){
		this.chequeNumber = chequeNumber;
	}
	
	public String getChequeNumber(){
		return this.chequeNumber;
	}
	
	public void setChequeDate(Date chequeDate){
		this.chequeDate = chequeDate;
	}
	
	public Date getChequeDate(){
		return this.chequeDate;
	}
	
}
