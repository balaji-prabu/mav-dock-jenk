package cc.streams.rejectedPayments;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class InvoiceBO {

    void findAllRejectedPayments(String input, String output) throws FileNotFoundException, IOException {
    	 //Fill your code
    //  invoice_number,customer name,cheque_number,cheque_date,bank_name,amount,status
//    	invoice number, cheque number,customer name, amount, status.
    		BufferedReader br = null;
    		FileReader fr = null;
    		fr = new FileReader(input);
    		br = new BufferedReader(fr);
    		
    		FileWriter fw = new FileWriter(output);
    		BufferedWriter bw = new BufferedWriter(fw);
    		

    		String sCurrentLine;

    		while ((sCurrentLine = br.readLine()) != null) {
    			String [] currentWords = sCurrentLine.split(",");
    			String invoiceNum = currentWords[0];
    			String custName = currentWords[1];
    			String cheqNum = currentWords[2];
    			String cheqDateStr = currentWords[3];
    			String bankName = currentWords[4];
    			String amountStr = currentWords[5];
    			String status = currentWords[6];
    			if(status.equals("Rejected")){
    				bw.write(invoiceNum+","+cheqNum+","+custName+","+amountStr+","+status+"\n");
    			}
    			
    		}
    		br.close();
    		bw.close();
    }
    
}

