package cc.streams.rejectedPayments;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;

public class Main {
	private static final String INPUT_FILENAME = "input.txt";
	private static final String OUTPUT_FILENAME = "output.txt";
	
	public static void main(String[] args) throws IOException, ParseException{
		InvoiceBO obj = new InvoiceBO();
		obj.findAllRejectedPayments(INPUT_FILENAME, OUTPUT_FILENAME);
		
	}
}

/*
 * Cuddles is a one stop shop for all your Baby needs. Jerlin, the owner of the Shop, has an automated Invoice Management System to maintain the invoices and payments and ensures a smooth cashflow. She has an option for her Customers to make payments through Cash, Cards and Cheque as well.

 

Jerlin wanted her application to update the payment cheque details from the clearing house. The cheque status are shared by the Bank with the below details in comma seperated format: invoice_number,customer name,cheque_number,cheque_date,bank_name,amount,status .

All the invoice details are provided in another file with customer information . Write a program to help Jerlin find all the cheques which are rejected by the bank. Write the output to the file in the following format, invoice number, cheque number,customer name, amount, status.


 */
