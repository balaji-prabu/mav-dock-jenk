package cc.streams.itemSummary;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {
	private static final String FILENAME = "input.txt";
	public static void main(String args[]) throws FileNotFoundException, IOException {

		//Fill your code
		BufferedReader br = null;
		FileReader fr = null;
		fr = new FileReader(FILENAME);
		br = new BufferedReader(fr);

		String sCurrentLine;

		while ((sCurrentLine = br.readLine()) != null) {

			String id = sCurrentLine.substring(0, 3) ;
			String internalNumber = sCurrentLine.substring(4, 8) ;
			String deleted = sCurrentLine.substring(9, 10) ;
			String currencyId = sCurrentLine.substring(11, 14) ;
			String price = sCurrentLine.substring(15);

			Item item=new Item(Long.parseLong(id), internalNumber, Integer.parseInt(deleted), Long.parseLong(currencyId), Double.parseDouble(price));

		}


//		System.out.println("Number of active items :"+ activeItemsCount);
//		System.out.println("Number of deleted items :"+deletedItemsCount);
	}
}
