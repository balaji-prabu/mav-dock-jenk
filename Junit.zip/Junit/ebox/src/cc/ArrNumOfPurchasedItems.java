package cc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ArrNumOfPurchasedItems {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int numOfItems=Integer.parseInt(br.readLine());
		int listOfPrices[]=new int[numOfItems];
		int zeroTo25 = 0, t25To50 = 0, f50To100 = 0, h100To500 = 0, f500To1000 = 0;
		for(int i=0;i<numOfItems;i++){
			listOfPrices[i]=Integer.parseInt(br.readLine());
			
			if(listOfPrices[i] > 1000){
				System.out.println("Invalid Input");
				return;
			}
			
			else if(listOfPrices[i] > 0 && listOfPrices[i] <= 25){
				zeroTo25++;
			}
			
			else if(listOfPrices[i] > 25 && listOfPrices[i] <= 50){
				t25To50++;
			}
			
			else if(listOfPrices[i] > 50 && listOfPrices[i] <= 100){
				f50To100++;
			}
			
			else if(listOfPrices[i] > 100 && listOfPrices[i] <= 500){
				h100To500++;
			}
			
			else if(listOfPrices[i] > 500 && listOfPrices[i] <= 1000){
				f500To1000++;
			}
		}
		
		System.out.println("The number of items between 0 to 25 :"+zeroTo25);
		System.out.println("The number of items between 25 to 50 :"+t25To50);
		System.out.println("The number of items between 50 to 100 :"+f50To100);
		System.out.println("The number of items between 100 to 500 :"+h100To500);
		System.out.println("The number of items between 500 to 1000 :"+f500To1000);

	}

}
