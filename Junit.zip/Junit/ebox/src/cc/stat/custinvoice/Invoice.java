package cc.stat.custinvoice;

public class Invoice {

	User customer;
	Double total;
	String status;
	String createdBy;
	
	Invoice(User customer, Double total, String status, String createdBy){
		this.customer = customer;
		this.total = total;
		this.status = status;
		this.createdBy = createdBy;
	}
	
	public User getCustomer(){
		return this.customer;
	}
	
	public Double getTotal(){
		return total;
	}
	
	public String getStatus(){
		return status;
	}
	
	public String getCreatedBy(){
		return createdBy;
	}
	
}
