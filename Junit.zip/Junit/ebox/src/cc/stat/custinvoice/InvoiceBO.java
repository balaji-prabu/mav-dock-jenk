package cc.stat.custinvoice;

public class InvoiceBO {
	public void displayUserDetailsByStatus(String status,Invoice[] invoiceArray) {
		// fill code here
		for(Invoice currInvoice : invoiceArray){
			if(currInvoice.getStatus().equalsIgnoreCase(status)){
				System.out.println(currInvoice.getCustomer().toString());
			}
		}
	}
	public double getTotalInvoiceValue(String userName,Invoice[] invoiceArray) {
		Double total = 0.0;
		for (Invoice currInvoice : invoiceArray){
			if(currInvoice.getCreatedBy().equalsIgnoreCase(userName)){
				total = total + currInvoice.getTotal();
			}
		}
		return total;
		// fill code here
	}
}
