package cc.stat.custinvoice;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of invoices :");
		int n = Integer.parseInt(buf.readLine());
					// fill code here
		Invoice [] invoiceList = new Invoice[n];
		for(int i=0; i< n; i++){
			System.out.println("Enter the invoice "+ (i+1) +" details :");
//			String currInvoiceDetails = buf.readLine();
			String [] currInvoiceDetails  = buf.readLine().split(",");
			invoiceList[i] = new Invoice(
					new User(currInvoiceDetails[0], currInvoiceDetails[1], currInvoiceDetails[2]),
					Double.parseDouble(currInvoiceDetails[3]),
					currInvoiceDetails[4],
					currInvoiceDetails[5]
					);
		}
		InvoiceBO invoiceBOObj = new InvoiceBO();
		System.out.println("Customer details with status cleared Invoices :");
		System.out.format("%-15s %-15s %-15s\n","Name","State","Country");
		
		invoiceBOObj.displayUserDetailsByStatus("Cleared", invoiceList);
//		print details
		System.out.println("Enter the Invoice creator name :");
		String userName = buf.readLine();
		System.out.println("The total invoice value :");
		Double result = invoiceBOObj.getTotalInvoiceValue(userName, invoiceList);
		if(result.equals(0.0D)){
			System.out.println("No invoice available");
		}
		else{
			DecimalFormat df = new DecimalFormat("0.00");
			System.out.println(df.format(result));
		}
		
	}

}