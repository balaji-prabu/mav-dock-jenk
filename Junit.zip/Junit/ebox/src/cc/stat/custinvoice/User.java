package cc.stat.custinvoice;

public class User {
	String name, state, country;
	
	User(String name, String state, String country){
		this.name = name;
		this.state = state;
		this.country = country;
	}
	
	public String getName(){
		return name;
	}
	
	public String getState(){
		return state;
	}
	
	public String getCountry(){
		return country;
	}
	
	public String toString(){
		return name + "%-15s " + state + "%-15s " + country + "%-15s ";
	}
}
