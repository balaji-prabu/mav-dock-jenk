package cc;

import java.io.*;
import java.util.*;
public class MaxMinUniq {
	public static void main(String args[])throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int getitems=Integer.parseInt(br.readLine());
		String inputitems[]=new String[getitems];


		//System.out.println("Enter the item id details");
		for(int i=0;i<getitems;i++)
		{
			inputitems[i]=br.readLine();    
		}
		HashMap<String, Integer> maxMinList = new HashMap<String, Integer>();
		for (int i = 0; i < inputitems.length; i++) 
		{
			String currentItem = inputitems[i]; 
			if(!maxMinList.containsKey(currentItem)){
				maxMinList.put(currentItem, 1);
			}
			else{
				int currentCount = maxMinList.get(currentItem);
				maxMinList.put(currentItem, currentCount++);
			}

			
		}


System.out.println(maxMinList);

	}
}
