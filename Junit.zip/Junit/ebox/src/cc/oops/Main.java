package cc.oops;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main{
    public static void main(String[] args) throws NumberFormatException, IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//fill your code
		String nextLoop = null;
		Array arrObj = new Array(new Integer[100]);
		do{
			System.out.println("Enter your choice"+
					"\n1.Add"+
					"\n2.Remove"+
					"\n3.Search");

			int choice = Integer.parseInt(br.readLine());
			Integer[] arr = null;
			switch(choice) {
			
			case 1:
				System.out.println("Enter the array value");
				
				int currentArrayValueToBeAdded = Integer.parseInt(br.readLine());
				arrObj.add(currentArrayValueToBeAdded);
				
				
				break;
			
			case 2:
				System.out.println("Enter the position to remove");
				int posToBeRemoved = Integer.parseInt(br.readLine());
				arr = arrObj.getArray();
				arrObj.remove(posToBeRemoved);
				
				
				break;
			
			case 3:
				System.out.println("Enter the element to search");
				int elementToBeSearched = Integer.parseInt(br.readLine());
				arrObj.search(elementToBeSearched);
				break;
				
				default:
					break;
				
			}
			
			System.out.println("Do you want to continue[Yes/No]");
			nextLoop = br.readLine();
		}while(nextLoop.equals("Yes"));

	}

}