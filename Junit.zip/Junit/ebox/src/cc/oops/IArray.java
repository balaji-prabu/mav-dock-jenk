package cc.oops;

public interface IArray {
	public  void add(Integer value);
	public  void remove(Integer value);
	public  void search(Integer value);
}
