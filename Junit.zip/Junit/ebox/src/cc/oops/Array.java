package cc.oops;

public class Array implements IArray{

	Integer array[] = new Integer[100];

	Array(){} 
	Array(Integer array[]){
		this.array = array;
	}

	void setArray(Integer array[]){
		this.array = array;
	}
	public Integer[] getArray(){
		return array;
	}

	@Override
	public void add(Integer value) {
		// TODO Auto-generated method stub
		int i = 0;
		for(; i < array.length; i++){
			if(array[i] == null)
				break;
		}
		array[i] = value;
		printArray();
	}
	@Override
	public void remove(Integer pos) {
		// TODO Auto-generated method stub

		int lastIndex = 0;
		for(;lastIndex < array.length; lastIndex++){
			if(array[lastIndex] == null)
				break;
		}

		if(pos < 0 || pos > lastIndex ){
			System.out.println("Enter the valid position");
			return;
		}
		else{
			for(int i = pos-1; i < array.length-1; i++){
				array[i] = array[i+1];
				if(array[i+1] == null)
					break;
			}
		}
		printArray();
	}
	@Override
	public void search(Integer value) {
		// TODO Auto-generated method stub
		boolean flag = false;
		for(int i =0; i< array.length;i++){
			if(array[i] == value){
				flag = true;
				break;
			}
			if(array[i] == null)
				break;

		}
		if(flag)
			System.out.println("Element found");
		else
			System.out.println("Element not found");
	}

	public void printArray(){
		System.out.println("The values are");
		for(int i = 0; i <array.length; i++){
			if(array[i] == null)
				break;
			System.out.println(array[i]);
		}
	}
}

