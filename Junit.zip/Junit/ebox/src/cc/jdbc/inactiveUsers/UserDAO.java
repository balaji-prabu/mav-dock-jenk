package cc.jdbc.inactiveUsers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import cc.jdbc.purchaseOrder.DBUtils;
import cc.jdbc.inactiveUsers.User;


public class UserDAO {

	public void makeInActive(int failedAttempts) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		// fill the code
		Connection conn=null;
		/*try{
			conn=DBUtils.getConnection();
			Statement stmt = null;
			stmt = conn.createStatement();
			String query = "SELECT id FROM user where failed_attempts>="+failedAttempts;
			ArrayList<Integer> listofMatches = new ArrayList<Integer>();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()){
				int id=rs.getInt("id");
				listofMatches.add(id);
			}
			rs=null;
			for(Integer currentId:listofMatches ){
				String currentQuery = "UPDATE user SET deleted=1 where id="+currentId;
				stmt.executeUpdate(currentQuery);
			}
		} catch(Exception e){
			e.printStackTrace();
		}*/
		
		conn=Connector.getConnection();
		Statement stmt = null;
		stmt = conn.createStatement();
	
	
	
			String currentQuery = "UPDATE user SET deleted=1 failed_attempts = "+failedAttempts;
			stmt.executeUpdate(currentQuery);

	}

	public ArrayList<User> getInActiveUsers() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		// fill the code
		ArrayList<User> list=new ArrayList<User>();
		Connection conn=null;
		try{
			conn=DBUtils.getConnection();
			Statement stmt = null;
			stmt = conn.createStatement();

			String query = "SELECT username,address,mobile_number "+
					"FROM user where deleted=1";

			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()){

				String username=rs.getString("username");
				String address=rs.getString("address");
				String mobNum=rs.getString("mobile_number");

				User currUser = new User();
				currUser.setUsername(username);
				currUser.setAddress(address);
				currUser.setMobile_number(mobNum);


				list.add(currUser);
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}




}
