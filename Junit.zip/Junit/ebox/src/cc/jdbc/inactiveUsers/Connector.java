package cc.jdbc.inactiveUsers;
import java.util.Properties;
import java.util.ResourceBundle;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Connector {
	
	public static Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
	// fill the code
		
		
		Class.forName("com.mysql.jdbc.Driver");
		//Retrieve connection configuration properties from "mysql.properties" file
		ResourceBundle rb = ResourceBundle.getBundle("mysql");
		String url = rb.getString("db.url");
		String username = rb.getString("db.username");
		String password = rb.getString("db.password");
		//System.out.format("url=%s\nusername=%s\npassword=%s\n",url,username,password);

		//Define a connection class' object

		Connection connect = null;
		try{
			//Define a Properties class' object and set 'user' and 'pasword' properties
			Properties properties=new Properties();
			properties.put("user",username);
			properties.put("password",password);
			connect=DriverManager.getConnection(url,properties);
		}catch(SQLException e){
			System.out.println(e);
			connect=null;
		} 

		//Return Connection object
		return connect;
	}
	
}

