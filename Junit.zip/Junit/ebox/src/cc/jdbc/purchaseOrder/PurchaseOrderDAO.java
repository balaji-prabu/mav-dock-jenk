package cc.jdbc.purchaseOrder;

import java.util.List;

public class PurchaseOrderDAO {

    public void createPurchaseOrder(PurchaseOrder po) {
          //fill your code
        
    }
    
    public List<PurchaseOrder> getAllPurchaseOrder() {
         //fill your code
    	return null;
    }
    
}