package cc.jdbc.purchaseOrder;

import java.io.IOException;
import java.text.ParseException;

public class Main {
    public static void main(String args[]) throws IOException, ParseException {
        
        //fill your code
  }
}


/*
Tisin works as a Finance Assistant at �Benison Hypermarket� and she is the primary authority 
who controls the financial transactions of the store. Inorder to get away with the difficulties of manually written purchase orders,
 Tisin came up to design an automated program that will create a purchase order based on the items provided by the Users.



The program should initially display all the available items at the store, with the items' Id, name, 
quantity available and the price of it. The program should then create a purchase order based on the number of items
 and quantities of the items provided by the Users and displays the purchase order in the desired format. 
 
 If a particular item requested by the Users are not available in the warehouse of the store, 
 the program should throw an exception "InsufficientQuantityException" which will display the message that the item is unavailable.
  Write a program to help her accomplish the task.
*/