package cc.jdbc.purchaseOrder;

public class InsufficientQuantityException extends Exception{

    public InsufficientQuantityException() {
        
    }
    
    public InsufficientQuantityException(String message) {
        super(message);
    }
    
}

