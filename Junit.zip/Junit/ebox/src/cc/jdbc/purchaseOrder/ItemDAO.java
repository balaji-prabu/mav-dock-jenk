package cc.jdbc.purchaseOrder;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

	public List<Item> getAllItems() {
		//fill your code
		List<Item> list=new ArrayList<Item>();
		Item it=null;
		Connection conn=null;
		try{
		conn=DBUtils.getConnection();
		Statement stmt = null;
		stmt = conn.createStatement();

		String query = "SELECT id,name,available_quantity,price "+
				"FROM item";

		ResultSet rs = stmt.executeQuery(query);
			while(rs.next()){
				Long id=(long) rs.getInt("item.id");        
				String username=rs.getString("item.name");
				Integer quantity=rs.getInt("item.available_quantity");
				double price=rs.getDouble("item.price");
				it=new Item(id,username,quantity,price);
				list.add(it);
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		return list;

	}    
}

