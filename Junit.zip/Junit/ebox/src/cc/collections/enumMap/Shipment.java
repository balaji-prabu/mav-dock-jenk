package cc.collections.enumMap;

 

public class Shipment {
	
	private String customerName;
	private String bookingNumber;
	private Double weight;
	private String status;
	
	Shipment(String custName, String bookingNum, Double weight, String status){
		this.customerName = custName;
		this.bookingNumber = bookingNum;
		this.weight= weight;
		this.status = status;
	}
	
	public void setCustName(String custName){
		this.customerName = custName;
	}
	
	public String getCustName(){
		return this.customerName;
	}
	
	public void setBookingNum(String bookNum){
		this.bookingNumber = bookNum;
	}
	
	public String getBookingNum(){
		return this.bookingNumber;
	}
	
	public void setWeight(Double wt){
		this.weight = wt;
	}
	
	public Double getWeight(){
		return this.weight;
	}
	
	public void setStatus(String status){
		this.status = status;
	}
	
	public String getStatus(){
		return this.status;
	}
}
