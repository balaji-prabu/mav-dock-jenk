package cc.collections.enumMap;

	public enum ShipmentStatus {         DELIVERED, TRANSIT, PENDING;   }
