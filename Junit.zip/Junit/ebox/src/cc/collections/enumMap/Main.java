package cc.collections.enumMap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		System.out.println("Enter the number of shipments");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int numOfShipments = Integer.parseInt(br.readLine());
		EnumMap<ShipmentStatus, List<Shipment>> mapObj = new EnumMap<ShipmentStatus, List<Shipment>>(ShipmentStatus.class);
		for(int i = 0; i<numOfShipments; i++){
			String currentInput = br.readLine();

			String [] inputSplit = currentInput.split(",");
			Shipment currentShipmentObj = new Shipment(inputSplit[0], inputSplit[1], Double.parseDouble(inputSplit[2]), inputSplit[3]);
			String currentStatus = inputSplit[3];

			List<Shipment> currentList = null;
			
			if(currentStatus.equals("DELIVERED")){
				currentList = mapObj.get(ShipmentStatus.DELIVERED);
				if(currentList == null)
					currentList = new ArrayList<Shipment>();
				currentList.add(currentShipmentObj);
				mapObj.put(ShipmentStatus.DELIVERED, currentList);
			}
			else if(currentStatus.equals("PENDING")){
				currentList = mapObj.get(ShipmentStatus.PENDING);
				if(currentList == null)
					currentList = new ArrayList<Shipment>();
				currentList.add(currentShipmentObj);
				mapObj.put(ShipmentStatus.PENDING, currentList);
			}
			else if(currentStatus.equals("TRANSIT")){
				currentList = mapObj.get(ShipmentStatus.TRANSIT);
				if(currentList == null)
					currentList = new ArrayList<Shipment>();
				currentList.add(currentShipmentObj);
				mapObj.put(ShipmentStatus.TRANSIT, currentList);
			}
		}
		System.out.println("Display");
		System.out.println("1.Delivered Shipments");
		System.out.println("2.Pending Shipments");
		System.out.println("3.Transit Shipments");
		String currentInput = br.readLine();
		List<Shipment> result = null;
		if(currentInput.equals("1"))
			result = mapObj.get(ShipmentStatus.DELIVERED);
		else if(currentInput.equals("2"))
			result = mapObj.get(ShipmentStatus.PENDING);
		else if(currentInput.equals("3"))
			result = mapObj.get(ShipmentStatus.TRANSIT);

		for(Shipment currentShipment : result){
			System.out.format("%-15s%-15s\n", currentShipment.getCustName(), currentShipment.getBookingNum());
		}

	}

}

/*
 * VLC shipment company had an application which keeps track of the shipments. Unfortunately, the application was not able to group the shipment details based on the shipment statuses. So the Management has assigned you decided to modify the existing application in such a way that he can easily retrieve the shipments based on the status. Write a program to build a hashmap - with three shipmentstatus as key (delivered, transit, yet to board) and the value would be a list of shipments entity. Display the shipment names in a list using EnumMap. 

Specification:
Use EnumMap <ShipmentStatus,List<Shipment>>

  public enum ShipmentStatus {         DELIVERED, TRANSIT, PENDING;   } 

Create a class Shipment with following private attributes

String customerName
String bookingNumber
Double weight
String status
Include appropriate constructors, getters, and setters.


Input Format:
The first input consists of an Integer 'n' which corresponds to number of shipments.
The next 'n' input corresponds to the Shipment details in the order customer name, booking number, weight, status.
The next input corresponds to which type of shipment status to be displayed.

  Output Format:
The output consists of the shipment names and booking number of the selected status.
Use System.out.format("%-15s%-15s\n");

Sample Input and Output:  
Enter the number of shipments
5
John,2110,50,DELIVERED
Clarke,2112,250,PENDING
Ricky,2108,300,TRANSIT
Abby,2115,300,DELIVERED
Roy,2108,310,DELIVERED
Display
1.Delivered Shipments
2.Pending Shipments
3.Transit Shipments
1
John           2110           
Abby           2115           
Roy            2108
 */
