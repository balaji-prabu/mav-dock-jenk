package cc.string.variousDateFormat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
		System.out.println("Enter the date:");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date inputDate = inputFormat.parse(br.readLine());
		System.out.println("Various formats:");
		SimpleDateFormat outputFormat1 = new SimpleDateFormat("EEE, MMM d, yy");
		SimpleDateFormat outputFormat2 = new SimpleDateFormat("dd.MM.yyyy");
		SimpleDateFormat outputFormat3 = new SimpleDateFormat("MM-dd-yyyy");
		System.out.println(outputFormat1.format(inputDate));
		System.out.println(outputFormat2.format(inputDate));
		System.out.println(outputFormat3.format(inputDate));
	}

}

/*
 * Emmett is working in a Mediterranean Shipping Company. Her work is to verify the shipping details and send a response to the users about the details. Users may ask date details in different formats for their clarifications.
Most frequently asked formats are
EEE, MMM d, yy
dd.MM.yyyy
MM-dd-yyyy

Help her by writing a program to parse the date to various formats. So that it will be helpful for her to response quickly.

Input Format:
The input corresponds to date in the format dd/MM/yyyy. 

Output Format:
First line output corresponds to the date format "EEE, MMM d, yy".
Second line output corresponds to the date format "dd.MM.yyyy".
Third line output corresponds to the date format "MM-dd-yyyy". 
Refer sample input and output for formatting specifications. 

[All text in bold corresponds to input and rest corresponds to output.] 
Sample Input and Output 1:
Enter the date:
28/08/1996
Various formats:
Wed, Aug 28, 96
28.08.1996
08-28-1996 
 */
