package lc.jdbc.userRole;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        //Obtain ArrayList from UserDAO class 
        UserDAO userDetails=new UserDAO();
        //Define arrayList to store user details obtained from UserDAO class
        ArrayList<User> userList=new ArrayList<User>();
        userList=userDetails.getAllUsers();
        //Sort ArrayList based on username using Comparator
        Collections.sort(userList,new UserNameComparator());
//        Collections.sort(userList);
        //Traverse through sorted user list and display result to user
        System.out.format("%-10s %-20s %-25s %-10s %-10s \n","User","Role","Street","City","State");
        Iterator itr=userList.iterator();
        while(itr.hasNext()){
            User user=(User)itr.next();
            System.out.format("%-10s %-20s %-25s %-10s %-10s \n",user.getName(),user.getRole().getName(),user.getContact().getStreet(),user.getContact().getCity(),user.getContact().getState());
        }
    }
}