package lc.jdbc.userRole;

import java.sql.*;
import java.util.*;

public class UserDAO 
{
    public ArrayList<User> getAllUsers() {
        //Define an ArrayList to store user details
        ArrayList<User> userList=new ArrayList<User>();
        //Define connection reference variable
        Connection connect=null;
        try{
          //Obtain Connection object by calling DbConnection class' method getConnection
          connect=DbConnection.getConnection();
          //Construct SQL query
          String fetchUserDetails="SELECT user.id,user.name,role.id,role.name,contact.id,contact.street,contact.city,contact.state "+
                                  "FROM user,role,contact "+
                                  "WHERE user.contact_id=contact.id && user.role_id=role.id";
          //Create Statement to represent SQL query
          //System.out.println(connect);
          Statement stmt=connect.createStatement();
          //Execute query and store result in ResultSet object
          ResultSet rs=stmt.executeQuery(fetchUserDetails);
          //Traverse through ResultSet and add User object in ArrayList
          while(rs.next())
          {
            userList.add(new User(rs.getInt("user.id"),rs.getString("user.name"),
            new Role(rs.getInt("role.id"),rs.getString("role.name")),
            new Contact(rs.getInt("contact.id"),rs.getString("contact.street"),
            rs.getString("contact.city"),rs.getString("contact.state"))));  
          }
        //Sort ArrayList based on username using Comparator
//        Collections.sort(userList);
        //Close connection
        connect.close();
        }catch(SQLException e){
            System.out.println(e);
        }catch(InstantiationException e){
            System.out.println(e);
        }catch(IllegalAccessException e){
            System.out.println(e);
        } catch(ClassNotFoundException e){
            System.out.println(e);
        }
          //Return ArrayList
          return userList;
    }
}
