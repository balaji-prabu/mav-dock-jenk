package lc.jdbc.assignprivileges;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class Main {
    public static void main(String[] args) throws NumberFormatException, IOException, ClassNotFoundException, SQLException {
        
    	RoleDAO roleDAO = new RoleDAO();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        PrivilegeDAO privilegeDAO = new PrivilegeDAO();
        List<Privilege> privileges = privilegeDAO.getAllPrivileges();
        System.out.println("List of privileges :");
        System.out.format("%-15s %s\n","Privilege ID","Privilege Name");
        for(int i=0;i<privileges.size();i++) {
        	System.out.format("%-15s %s\n",privileges.get(i).getId(),privileges.get(i).getName());
        }
        
        System.out.println("Enter number of new Roles to be created :");
        Integer n = Integer.parseInt(br.readLine());
        
        System.out.println("Enter the role and privileges :");

        //fill the code
                int i=0;
        ArrayList<Privilege> privilegeList=new ArrayList<Privilege>();  //Define a list to store privileges per role   
        for(;i<n;i++){
            String[] rolePrivilegeDetails=br.readLine().split(",");        
            //Construct privilege list for given role
            Privilege currPrivilege = null;
            for(int j=1;j<rolePrivilegeDetails.length;j++){
                //Add privilege object to list with default privilege id=0
            	currPrivilege = new Privilege(0,rolePrivilegeDetails[j]);
                privilegeList.add(currPrivilege);
            }    
            //Construct Role object(with default role id=0) and pass to 'createRole' method
            new RoleDAO().createRole(new Role(0,rolePrivilegeDetails[0]),privilegeList);
            //Clear privilegeList elements
            privilegeList.clear();
        }

        System.out.println("Enter the Role :");
        String rol = br.readLine();
        System.out.println("Privileges for "+rol+" :");

        //fill the code
                //Get Privileges for given role
        List<Privilege> rolePrivileges=new RoleDAO().getPreviligeByRole(rol);
        //Display privileges to user
        String [] splitList = "".split("0");
        Iterator iterator=rolePrivileges.iterator();
        while(iterator.hasNext()){
            System.out.println(((Privilege)iterator.next()).getName());
        }
    }
}

/*
 * Observations : 
Compilation Errors Main.java:29: error: no suitable constructor found for Role(String) 
Role roleIns = new Role(splittedString[0]); ^ constructor Role.Role(Integer,String) is not applicable (actual and formal argument lists differ in length) constructor Role.Role() is not applicable (actual and formal argument lists differ in length) 1 error
 */

