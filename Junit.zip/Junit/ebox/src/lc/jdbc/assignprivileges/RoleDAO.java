package lc.jdbc.assignprivileges;

import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RoleDAO {

    public void createRole(Role roleIns, ArrayList<Privilege> privilegeList) throws SQLException, ClassNotFoundException {

    	//fill the code
        
                Connection connect=DbConnection.getConnection();
        //Populate Role table with given role name
          //Construct a preparedStatement
          String query="INSERT INTO role (name) values(?)";
          PreparedStatement insertRole=connect.prepareStatement(query);
          insertRole.setString(1,roleIns.getRoleName());
          insertRole.executeUpdate();
        //Retrieve auto-generated role id for given role name and set to Role object
          Statement retrieveRoleId=connect.createStatement();
          ResultSet rsRoleId=retrieveRoleId.executeQuery(String.format("SELECT role.id FROM role WHERE role.name=\'%s\'",roleIns.getRoleName()));
          rsRoleId.next();
          roleIns.setId(rsRoleId.getInt("role.id"));
        //Populate role_privilege table for given role and privileges
          //Construct a preparedStatement
          String query1="INSERT INTO role_privilege values(?,?)";
          PreparedStatement insertPrivilege=connect.prepareStatement(query1);
          //Traverse through 'privilegeList' and populate 'role_privilege' table for given role
          Iterator itr=privilegeList.iterator();
          while(itr.hasNext()){
            Privilege p=(Privilege)itr.next();
            //Retrieve Privilege Id for given privilege name from 'privilege' table
            Statement retrievePrivilegeId=connect.createStatement();
            ResultSet rsPrivilegeId=retrievePrivilegeId.executeQuery(String.format("SELECT privilege.id FROM privilege WHERE privilege.name=\'%s\'",p.getName()));
            rsPrivilegeId.next();
            //Set values in preparedStatement
            insertPrivilege.setInt(1,roleIns.getId());
            insertPrivilege.setInt(2,rsPrivilegeId.getInt("privilege.id"));
            //Execute preparedStatement
            insertPrivilege.executeUpdate();
          }

    }
    
    public List<Privilege> getPreviligeByRole(String role) throws ClassNotFoundException, SQLException {

            List<Privilege> privileges=new ArrayList<Privilege>();
        //Obtain connection object
        Connection connect=DbConnection.getConnection(); 
        //Get Role Id for given role
        String getRoleId="SELECT role.id FROM role WHERE role.name=?";
        PreparedStatement getRoleIdStmt=connect.prepareStatement(getRoleId);
        getRoleIdStmt.setString(1,role);
        ResultSet rs=getRoleIdStmt.executeQuery();
        rs.next();  //Initially ResultSet cursor points before the first row. Hence move pointer ahead
        int roleId=rs.getInt("role.id");
        //System.out.println("Role id="+roleId);
     //Get privilege_id's for given role Id
          String selectPrivilegeIdsForGivenRole=String.format("SELECT role_privilege.privilege_id "+
                                                "FROM role_privilege "+
                                                "WHERE role_privilege.role_id=%d",roleId);
          Statement selectPrivilegeIdsForGivenRoleStmt=connect.createStatement();
          ResultSet privilegeIds=selectPrivilegeIdsForGivenRoleStmt.executeQuery(selectPrivilegeIdsForGivenRole);
          //For each privilege_Id get corresponding privilege name from privilege table
          PreparedStatement getPrivilegeNameStmt=connect.prepareStatement("SELECT privilege.name FROM privilege WHERE privilege.id=?");
          while(privilegeIds.next()){
            //Set privilege id  
            //System.out.println("Assignes p Id="+privilegeIds.getInt("role_privilege.privilege_id"));
            getPrivilegeNameStmt.setInt(1,privilegeIds.getInt("role_privilege.privilege_id"));  
            ResultSet pName=getPrivilegeNameStmt.executeQuery();
            //Move pName cursor ahead by one position and retrieve privilege name
            pName.next();
            //System.out.println("Retrieved pname="+pName.getString("privilege.name"));
            //Add privilege object to list
            privileges.add(new Privilege(privilegeIds.getInt("role_privilege.privilege_id"),pName.getString("privilege.name")));
          }
        
        return privileges;


    }

}
