package lc.jdbc.assignprivileges;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;

public class PrivilegeDAO {
 
 public List<Privilege> getAllPrivileges() throws SQLException, ClassNotFoundException {
  //Obtain connection object
        Connection connect=DbConnection.getConnection();
        //Construct the query to retieve all privileges from db
        String privileges="SELECT * FROM privilege";
        //Create a Statement object that represents query onject
        Statement stmt=connect.createStatement();
        //Execute query and store result in ResultSet
        ResultSet rs=stmt.executeQuery(privileges);
        //Traverse through resultSet and construct list of 'Privilege' objects
        List<Privilege> privilegeList=new ArrayList<Privilege>();
        while(rs.next()){
            privilegeList.add(new Privilege(rs.getInt("privilege.id"),rs.getString("privilege.name")));
        }
        //Sort privilegeList
        Collections.sort(privilegeList);
        //Return privilegeList to calling method
        return privilegeList;
 }
 
}

