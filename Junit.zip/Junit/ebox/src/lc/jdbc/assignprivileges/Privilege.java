package lc.jdbc.assignprivileges;

public class Privilege implements Comparable<Privilege>{
    //Member variables
    private Integer id;
    private String name;
    //Constructors
    public Privilege(){}
    
    public Privilege(String name){
        this.name = name;
    }
    public Privilege(Integer id, String name) {
        this.id = id;
        this.name = name;
    }
    //Member methods
    //Implement 'compareTo' method
    @Override
    public int compareTo(Privilege privilege){
        return(this.getId()-privilege.getId());    
    }
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}

