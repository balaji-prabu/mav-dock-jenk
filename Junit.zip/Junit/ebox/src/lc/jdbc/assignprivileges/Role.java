package lc.jdbc.assignprivileges;

public class Role implements Comparable<Role>{
    //Member variables
    private Integer id;
    private String roleName;
    private String description;
    //Constructors
    public Role(){}
    
    public Role(Integer id, String roleName) {
        this.id = id;
        this.roleName = roleName;
//        this.description = description;
    }
    //Member methods
    @Override
    public int compareTo(Role role){
        return(this.getRoleName().compareTo(role.getRoleName()));
    }
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getRoleName() {
        return roleName;
    }
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}

