import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hamcrest.Matcher;
import org.hamcrest.collection.IsMapContaining;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.MatcherAssert.assertThat;

public class ItemJunit {

	ItemBO itemBO;
	
	@Before
	public void init() {
		//fill the code
		itemBO = new ItemBO();
	}
	
	@Test
	public void testItemCount() {
		//fill the code
		String i1 = "1,i1,10";
		String i2 = "2,i2,10";
		String i3 = "3,i1,10";
		String i4 = "4,i3,10";
		String i5 = "5,i1,10";
		String[] items = new String[5];
		items[0] = i1; items[1] = i2; items[2] = i3; items[3] = i4; items[4] = i5;
		
		HashMap<String, Integer> resultMap = itemBO.findItemCount(items, items.length);
//		List<org.hamcrest.Matcher<>> itemMatchers = new ArrayList<Matcher<>>();
		assertThat(resultMap,hasEntry("i1",3));
	}
	
	@After
	public void destroy() {
		//fill the code
		itemBO = null;
	}

}
