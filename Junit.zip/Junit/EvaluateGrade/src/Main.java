import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Main {
		public static void main(String[] args) throws Exception {
		int countries;
		int shipmentpermonth;
		BufferedReader bufferedReader = new BufferedReader(
				new InputStreamReader(System.in));

		System.out.println("Enter the total number of countries :");
		countries = Integer.parseInt(bufferedReader.readLine());
		System.out.println("Enter the total number of shipment per month :");
		shipmentpermonth = Integer.parseInt(bufferedReader.readLine());

		ShipmentBO shipmentBO = new ShipmentBO();
		String grade = shipmentBO.evaluateGrade(countries, shipmentpermonth);
		System.out.println("The company grade is:" + grade);
	}

}
