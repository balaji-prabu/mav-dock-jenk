import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.both;
import static org.junit.Assert.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
public class CustomerJunit {
	
	CustomerBO customerBO;
	
@Before
	public void init() {
		customerBO = new CustomerBO();
	}

@Test
	public void testFrequentCustomers() {
		List<Commodity> list = new ArrayList<Commodity>();
		list.add(new Commodity(10.0,10.0,new CommodityIdentification("commodity1", "Model1", "serial1", new Customer("Sudheer", "test@test.com"))));
		list.add(new Commodity(20.0,20.0,new CommodityIdentification("commodity2", "Model2", "serial2", new Customer("Sudheer1", "test2@test.com"))));
		list.add(new Commodity(20.0,20.0,new CommodityIdentification("commodity3", "Model3", "serial3", new Customer("Sudheer", "test@test.com"))));
		list.add(new Commodity(10.0,10.0,new CommodityIdentification("commodity1", "Model1", "serial1", new Customer("Sudheer", "test@test.com"))));
		list.add(new Commodity(20.0,20.0,new CommodityIdentification("commodity2", "Model2", "serial2", new Customer("Sudheer1", "test2@test.com"))));
		list.add(new Commodity(20.0,20.0,new CommodityIdentification("commodity2", "Model2", "serial2", new Customer("Sudheer1", "test2@test.com"))));
		list.add(new Commodity(20.0,20.0,new CommodityIdentification("commodity2", "Model2", "serial2", new Customer("Sudheer12", "test22@test.com"))));


		List<Customer> x = customerBO.findFrequentCustomers(list);
		assertThat(x, containsInAnyOrder(hasProperty("name",equalTo("Sudheer")),hasProperty("name",equalTo("Sudheer1"))));
	}
	
	
	public void destroy() {
		customerBO = null;
	}

}
