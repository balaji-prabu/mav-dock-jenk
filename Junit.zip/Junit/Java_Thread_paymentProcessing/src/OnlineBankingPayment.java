


public class OnlineBankingPayment implements Runnable//fill in your code here
{

    Long invoiceNumber;
    String accountNumber;
    Double amount;
    
    public OnlineBankingPayment(Long invoiceNumber,String accountNumber,Double amount) {
        this.invoiceNumber = invoiceNumber;
        this.accountNumber = accountNumber;
        this.amount = amount;
    }
    
    public void run() {

    	try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
       //fill in your code here
    	if(this.accountNumber.contains("555"))
    		System.out.println("Oops! Payment processing failed using the credit card number "+this.accountNumber);
    	else	
    		System.out.println("Payment processing completed using the Online banking");
        
    }
    
}
