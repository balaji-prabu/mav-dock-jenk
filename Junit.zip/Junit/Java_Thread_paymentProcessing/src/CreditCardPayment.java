
public class CreditCardPayment extends Thread{
    
    private Long invoiceNumber;
    private String cardNumber;
    private Double amount;
    
    public CreditCardPayment(Long invoiceNumber,String cardNumber,Double amount) {
        this.invoiceNumber = invoiceNumber;
        this.amount = amount;
        this.cardNumber = cardNumber;
    }
    
    public void run() {
    	try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       //fill in your code here
    	if(this.cardNumber.contains("555"))
    		System.out.println("Oops! Payment processing failed using the credit card number "+this.cardNumber);
    	else	
    		System.out.println("Payment processing completed using Credit card");
        
    }
}
