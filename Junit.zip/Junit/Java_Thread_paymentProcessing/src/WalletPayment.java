


public class WalletPayment implements Runnable//fill in your code here
{

    Long invoiceNumber;
    String mobileNumber;
    Double amount;
    
    public WalletPayment(Long invoiceNumber,String mobileNumber,Double amount) {
        this.invoiceNumber = invoiceNumber;
        this.mobileNumber = mobileNumber;
        this.amount = amount;
    }
    
    public void run() {
    
    	try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

       //fill in your code here
    	if(this.mobileNumber.contains("555"))
    		System.out.println("Oops! Payment processing failed using the wallet mobile number "+this.mobileNumber);
    	else	
    		System.out.println("Payment processing completed using Wallet payment");
        
    }
    
}
