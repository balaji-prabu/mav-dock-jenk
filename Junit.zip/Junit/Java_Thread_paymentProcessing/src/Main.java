

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String args[]) throws IOException, InterruptedException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the number of payments:");
		int numberOfPayments = Integer.parseInt(reader.readLine());

		System.out.println("Enter the payment details (Invoice ID, ACC Number, Payment Amount, Payment Type)");
		List<String> input = new ArrayList<String>();
		for(int i=0;i<numberOfPayments;i++) {
			input.add(reader.readLine());
		}        

		for(String currentInput:input){
			String currentPaymentType = currentInput.split(",")[3];
			String currentID = currentInput.split(",")[0];
			String accNum = currentInput.split(",")[1];
			String paymentAmt = currentInput.split(",")[2];

			if(currentPaymentType.equals("OLB")){
				OnlineBankingPayment obj = new OnlineBankingPayment(Long.parseLong(currentID), accNum, Double.parseDouble(paymentAmt));
				Thread thread = new Thread(obj);
				thread.start();
				//        		olbObj.
			}
			else if(currentPaymentType.equals("CC")){
				CreditCardPayment obj = new CreditCardPayment(Long.parseLong(currentID), accNum, Double.parseDouble(paymentAmt));
				obj.start();
			}
			else if(currentPaymentType.equals("WA")){
				WalletPayment obj = new WalletPayment(Long.parseLong(currentID), accNum, Double.parseDouble(paymentAmt));
				Thread thread = new Thread(obj);
				thread.start();
			}
		}

		//fill in your code here



	}
}
