public class InvalidRoleException extends Exception {
	public InvalidRoleException(String str) {
		super(str);
	}
}