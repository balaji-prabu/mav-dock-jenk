import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class PasswordExceptionJunit {
	UserBO obj;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@Before
	public void userObjectCreation() {
		//fill the code
		obj = new UserBO();
	}

	@Test 
	
	public void testPasswordException() throws WeakPasswordException {
		User user1 = new User("user1", "mart@123!", "address1");
		obj.validatePassword(user1);
		
		expectedEx.expect(WeakPasswordException.class);
	    User user2 = new User("user2", "martinluther", "address1");
		obj.validatePassword(user2);
		
		User user3 = new User("user3", "mart", "address1");
		obj.validatePassword(user3);
		
		User user4 = new User("user4", "martine!", "address1");
		obj.validatePassword(user4);
		
		User user5 = new User("user5", "martine1", "address1");
		obj.validatePassword(user5);
		
		User user6 = new User("user6", "martine0!", "address1");
		obj.validatePassword(user6);
	}

}
