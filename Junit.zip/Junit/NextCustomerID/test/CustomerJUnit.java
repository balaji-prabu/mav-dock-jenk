import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

public class CustomerJUnit {
	CustomerBO customer;

	@Before
	public void setUp() {
		customer = new CustomerBO();
	}

	@Test
	 public void testFindNextCustomerId() {
	 //fill the code
	 Integer[] a = {21,34,65,1,3,76,43};
	 Integer[] b = {21};
	 assertThat(customer.findNextCustomerId(7, a), is(77));
	 //assertThat(customer.findNextCustomerId(5, a), is(65));
	 //assertThat(customer.findNextCustomerId(2, a), is(34));
	 //assertThat(customer.findNextCustomerId(1, a), is(21));
	 assertThat(customer.findNextCustomerId(1, b), is(22));
	 }
}
