public class Cargo {
	private String name;
	private String description;
	private double width;
	private double length;
	public Cargo() {}
	public Cargo(String name, String description, double width, double length) {
		this.name = name;
		this.description = description;
		this.width = width;
		this.length = length;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result
//				+ ((description == null) ? 0 : description.hashCode());
//		long temp;
//		temp = Double.doubleToLongBits(length);
//		result = prime * result + (int) (temp ^ (temp >>> 32));
//		result = prime * result + ((name == null) ? 0 : name.hashCode());
//		temp = Double.doubleToLongBits(width);
//		result = prime * result + (int) (temp ^ (temp >>> 32));
//		return result;
//	}
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Cargo other = (Cargo) obj;
//		if (description == null) {
//			if (other.description != null)
//				return false;
//		} else if (!description.equals(other.description))
//			return false;
//		if (Double.doubleToLongBits(length) != Double
//				.doubleToLongBits(other.length))
//			return false;
//		if (name == null) {
//			if (other.name != null)
//				return false;
//		} else if (!name.equals(other.name))
//			return false;
//		if (Double.doubleToLongBits(width) != Double
//				.doubleToLongBits(other.width))
//			return false;
//		return true;
//	}
//	
	
}