import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJunit {

	ShipmentBO shipmentBO;

	@Before
	public void createshipmentBO() {
		shipmentBO = new ShipmentBO();
	}

	@Test
	public void testLeftOutValue() {
		assertTrue(shipmentBO
				.findLeftOutValue(new double[] { 46.45, 23, 40, 68 }) == 23);

		assertTrue(shipmentBO.findLeftOutValue(new double[] { 46.45, 23 }) == 23);

		assertTrue(shipmentBO.findLeftOutValue(new double[] { 246.45, 823.43,
				63.98, 67.45, 63.98 }) == 63.98);

		assertTrue(shipmentBO.findLeftOutValue(new double[] { 246.45 }) == 246.45);

	}
}