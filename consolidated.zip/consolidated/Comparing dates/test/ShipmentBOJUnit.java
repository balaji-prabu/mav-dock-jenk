
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.*;

import org.junit.Test;



public class ShipmentBOJUnit {

	//Fill the code

	ShipmentBO shipmentBO = new ShipmentBO();
	Shipment[] shipment;
	SimpleDateFormat sdf  = new SimpleDateFormat("dd/MM/yyyy");;


	@Test
	public void testGetShipmentsOnSameDate_withArrivalDateNull() throws ParseException,NullPointerException {
		//Fill the code
		Boolean flag= false;

		try{
			Shipment[]  shipment= new Shipment[2];
			shipment[0] = new Shipment("simon",sdf.parse("10/11/2018"),null);
			shipment[1] = new Shipment("simons",sdf.parse("10/12/2018"),null);

			shipmentBO.getShipmentsOnSameDate(2, shipment);

		}
		catch(NullPointerException e){

			flag= true;

		}
		assertTrue(flag);



	}
	@Test
	public void testGetShipmentsOnSameDate_withNoShipments() {
		//Fill the code


		Shipment[]  shipment2 = null;


		ArrayList<String>   shipmentNames2 = shipmentBO.getShipmentsOnSameDate(0, shipment2);

		assertEquals(shipmentNames2.size(),0 );



	}
	@Test
	public void testGetShipmentsOnSameDate_withMultipleShipment() throws ParseException {
		//Fill the code



		Shipment[]  shipment3= new Shipment[2];
		shipment3[0] = new Shipment("simon",sdf.parse("10/11/2018"),sdf.parse("10/11/2018"));
		shipment3[1] = new Shipment("simons",sdf.parse("10/11/2018"),sdf.parse("10/11/2018"));

		ArrayList<String> shipmentNames3 = shipmentBO.getShipmentsOnSameDate(2, shipment3);

		assertThat(shipmentNames3, containsInAnyOrder("simon","simons"));




	}
	@Test
	public void testGetShipmentsOnSameDate_withNoShipmentOnSameDate() throws ParseException {
		//Fill the code


		Shipment[]  shipment4= new Shipment[2];
		shipment4[0] = new Shipment("simon",sdf.parse("10/11/2018"),sdf.parse("10/12/2018"));
		shipment4[1] = new Shipment("simons",sdf.parse("10/12/2018"),sdf.parse("10/13/2018"));

		ArrayList<String> shipmentNames4 = shipmentBO.getShipmentsOnSameDate(2, shipment4);

		assertTrue(shipmentNames4.size()==0);


	}
}
