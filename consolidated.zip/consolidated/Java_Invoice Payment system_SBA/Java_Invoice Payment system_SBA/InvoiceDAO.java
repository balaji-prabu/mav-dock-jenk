import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class InvoiceDAO {

	public List<Invoice> getAllInvoices() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		 //Fetch details of all the Invoices from invoice table in database and return the list of all the invoices. -
		List<Invoice> invList = new ArrayList<Invoice>();
		Statement st = null;
		
			st = DbConnection.getConnection().createStatement();
			ResultSet rs = st.executeQuery("SELECT id,customer_name,payment_attempts,total_amount,balance,status from invoice ");
			while(rs.next()){
				invList.add(new Invoice(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getDouble(5),rs.getString(6)));
			}
		
		
		return invList;
	}
	
	public void updateInvoiceDetails(Integer invoiceId, Double amount) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		PreparedStatement st  = DbConnection.getConnection().prepareStatement("update invoice set payment_attempts=payment_attempts+1,balance=? where id = ?");
			st.setDouble(1,amount);
			st.setInt(2,invoiceId);
			st.execute();
	}
}
