import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
public class Main {
	
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException, ParseException, InstantiationException, IllegalAccessException {
		
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		InvoiceBO bo = new InvoiceBO();
		List<Invoice> invList = bo.getAllInvoice();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Invoice Details:");
		System.out.format("%-5s %-15s %-20s %-15s %-10s %s\n","ID","Customer Name","Payment Attempts","Total Amount","Balance","Status");
		
		for(Invoice inv:invList){
			System.out.format("%-5s %-15s %-20s %-15s %-10s %s\n",inv.getId(),inv.getCustomerName(),inv.getPaymentAttempts(),inv.getTotalAmount(),inv.getBalance(),inv.getStatus());
		}
		
		System.out.println("Enter the invoice id to pay :");
		Integer id = Integer.parseInt(buff.readLine());
		System.out.println("Enter the name :");
		String name = buff.readLine();
		
		System.out.println("Enter the amount :");
		Double amount = Double.parseDouble(buff.readLine());
			
		System.out.println("Enter the card number :");
		String cardNo = buff.readLine();
		
		System.out.println("Enter the cvv :");
		String cvv = (buff.readLine());
			
		System.out.println("Enter the card name :");
		String cardName = buff.readLine();
			
		CreditCardPayment ccPay = new CreditCardPayment();
		ccPay.setAccountHolderName(name);
		ccPay.setAmount(amount);
		ccPay.setCardName(cardName);
		ccPay.setCvv(cvv);
		ccPay.setCardNumber(cardNo);		
		try{
		Double amt  = ccPay.calculateTotalAmount();
		System.out.printf("Total Amount to be paid is %.2f\n",amt);
		
		Double bal = 0.0;
		for(Invoice inv:invList){
			if(inv.getId()==id){
				bal = inv.getBalance() - amount;
				break;
			}
		}
		
		bo.updateInvoiceDetails(id,bal);
		
		//fill the code
		System.out.printf("The balance amount is %.2f",bal);
		}catch (InvalidPaymentException e) {
			// TODO: handle exception
		}
	}
	
	
}
