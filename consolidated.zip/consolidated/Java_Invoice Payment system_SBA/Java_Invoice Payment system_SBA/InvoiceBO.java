import java.sql.SQLException;
import java.util.List;
public class InvoiceBO {

	public List<Invoice> getAllInvoice() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		return new InvoiceDAO().getAllInvoices();
	}
	public void updateInvoiceDetails(int id,Double amount) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		new InvoiceDAO().updateInvoiceDetails(id, amount);
	}
	
}
