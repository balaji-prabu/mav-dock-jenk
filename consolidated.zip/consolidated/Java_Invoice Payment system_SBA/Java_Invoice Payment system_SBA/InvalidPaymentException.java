
public class InvalidPaymentException extends Exception {

	public InvalidPaymentException(){
		super();
		
	}
	public InvalidPaymentException(String s){
		
		System.out.println("InvalidPaymentException: "+s);
	}
}
