import java.util.List;

public interface IPaymentDAO {

    //fill the code
	
	public void insertPaymentDetails(List<Cheque> chequeList);

	public  Payment getPaymentById(Integer paymentId);
}