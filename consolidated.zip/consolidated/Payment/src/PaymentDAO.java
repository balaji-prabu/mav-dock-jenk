import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class PaymentDAO implements IPaymentDAO {    
      
	  public void insertPaymentDetails(List<Cheque> chequeList){
	     //fill hte code
		  Connection conn= null;
		  PreparedStatement stmt = null,stmt2=null;
		  String sql = null,sql2 = null;
		  try{
			  sql = "INSERT INTO cheque  VALUES (?,?,?,?) ";
			  sql2 = "INSERT INTO payment  VALUES (?,?,?,?,?,?) ";
			  conn = DBConnection.getConnection();
			  stmt = conn.prepareStatement(sql);
			  stmt2 = conn.prepareStatement(sql2);
			  for(Cheque c:chequeList){
				  stmt.setLong(1, c.getChequeId());
				  stmt.setString(2, c.getBankName());
				  stmt.setString(3, c.getChequeNumber());
				  stmt.setLong(4, c.getPayment().getId());
 
				  stmt2.setLong(1, c.getPayment().getId());
				  stmt2.setString(2, c.getPayment().getCustomerName());
				  stmt2.setString(3, c.getPayment().getInvoiceNumber() );
				  stmt2.setLong(4, c.getPayment().getAttempt());
				  stmt2.setDouble(5, c.getPayment().getAmount());
				  stmt2.setString(6, c.getPayment().getStatus());
				  
				
				  stmt2.execute();
				  stmt.execute();
			  }
			  
		  }catch(Exception e){
			  System.out.println(e.getMessage());
			  e.printStackTrace();
		  }finally{
			 
			try {
			  if(conn!=null){
				  conn.close();
			  }
			  if(stmt!=null){
				  stmt.close();
			  }
			  if(stmt2!=null){
				  stmt2.close();
			  }
			} catch (SQLException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
			  
		  }
		  
		  
     }

	  
	
	  public  Payment getPaymentById(Integer paymentId){
	       
		  //fill the code
	    	
		  Connection conn= null;
		  PreparedStatement stmt = null;
		  ResultSet rs = null;
		  String sql = null;
		  Payment pay = null;
		  try{
			  sql = "SELECT * FROM payment  WHERE id = ? ";
			  conn = DBConnection.getConnection();
			  stmt = conn.prepareStatement(sql);
			  
			  stmt.setLong(1, paymentId);
			  
			  rs = stmt.executeQuery();
			  if(rs.next()){
				  pay = new Payment(rs.getInt("ID"),
						  rs.getString("CUSTOMER_NAME"), 
						  rs.getString("INVOICE_NUMBER"), 
						  rs.getInt("ATTEMPT"), 
						  rs.getDouble("AMOUNT"), 
						  rs.getString("STATUS"));
			  }
		  }catch(Exception e){
			  System.out.println(e.getMessage());
			  e.printStackTrace();
		  }finally{
			 
			try {
			  if(conn!=null){
				  conn.close();
			  }
			  if(stmt!=null){
				  stmt.close();
			  }
			  if(rs!=null){
				  rs.close();
			  }
			} catch (SQLException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
			  
		  }
		  
		  return pay;
	    	
	  }

			
}