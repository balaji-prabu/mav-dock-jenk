import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

public class PaymentBO {

    public List<Cheque> getChequeList(String[] fileData) throws IOException, ClassNotFoundException, SQLException,InvalidPaymentException{        
	//fil the code	  
    	List<Cheque> cheques = new ArrayList<Cheque>();
	    	for(String line:fileData){
	    		String[] lineItems = line.split(",");
	    		if(lineItems.length != 9){
	    			new InvalidPaymentException("Incoreect Values");
	    		}
	    		try{
		    		if(!lineItems[2].startsWith("INV") ){
		    			throw new InvalidPaymentException("Invalid invoice number :"+lineItems[2]+"\nUpdate correct invoice number in file");
		    		}
		    		String num = lineItems[2].substring(3);
		    		Integer.parseInt(num);
		    		
		    		Payment payment= new Payment(Integer.parseInt(lineItems[0]), lineItems[1], lineItems[2],
		    				Integer.parseInt(lineItems[3]), Double.parseDouble(lineItems[4]), lineItems[5]);
		    		Cheque cheque= new Cheque(Integer.parseInt(lineItems[6]), lineItems[7], lineItems[8], payment) ;
		    		cheques.add(cheque);
		    	}catch (NumberFormatException e){
		    		throw new InvalidPaymentException("Invalid invoice number :"+lineItems[2]+"\nUpdate correct invoice number in file");
		    	}
	    	}
	    	PaymentDAO dao = new PaymentDAO();
	    	dao.insertPaymentDetails(cheques);
	    	
    	return cheques;
    	
	}	         
	          
	 
	public String[] getFileDetails() throws IOException{
		  BufferedReader br = br = new BufferedReader(new FileReader("Payment.csv"));
//		BufferedReader br = br = new BufferedReader(new FileReader("C:/eclipse/workspace/java/Payment/src/Payment.csv"));
		   //fill the code
		  
		  List<String> strings = new ArrayList<String>();
		  String line = null;
		  int i=0,j=0;
		 while(null!=(line= br.readLine())){
			 strings.add(line);
		 }
		 String[] strings2 = new String[strings.size()];
		 for(String string :strings){
			 strings2[j++] = string;
		 }
		 
		 return strings2;
	}
	

	
 }