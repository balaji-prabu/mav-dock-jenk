
public class InvalidPaymentException extends Exception{

  /**
 * @param arg0
 */
public InvalidPaymentException(String arg0){
	  super(arg0);
  }
	
  /**
 * @param arg0
 */
public InvalidPaymentException(Throwable arg0){
	  super(arg0);
  }
  
  /**
 * @param arg0
 * @param arg1
 */
public InvalidPaymentException(String arg0,Throwable arg1){
	  super(arg0,arg1);
  }
  
}