
import org.junit.Assert;
import org.junit.Test;


public class ShipmentBOJUnit {
	ShipmentBO shipBo = new ShipmentBO();
	ShipmentDAO shipDAO = new ShipmentDAO();
	@Test
	public void testUpdateShipment() throws Exception {
		//fill the code

		shipBo.updateShipment(1,12,shipDAO);
		Assert.assertEquals("Pending",shipDAO.getShipmentByID(1).getShipmentStatus().getName());
		
		shipBo.updateShipment(1,13,shipDAO);
		Assert.assertEquals("Delayed",shipDAO.getShipmentByID(1).getShipmentStatus().getName());		

	}
	@Test
	public void testUpdateShipment_failure() {
		//fill the code
		try{
			shipBo.updateShipment(100,12, shipDAO);
		}
		catch (Exception e){
			Assert.assertEquals("Update failed. Please enter a valid shipment id and shipment status id",e.getMessage());
		}
	}

	@Test(expected=Exception.class)
	public void testAddShipment()throws Exception {
		//fill the code
		shipBo.addShipment(new Shipment(3,"shipment3","Missouri","Dhaka",2345, new ShipmentStatus(12,"Pending",123)),14,shipDAO);
		
	}
	
	@Test
	public void testAddShipment_failure() {
		//fill the code
		try{
			shipBo.addShipment(new Shipment(3,"shipment3","Missouri","Dhaka",2345, new ShipmentStatus(14,"Pending",123)),15,shipDAO);
		}catch (Exception e){
			Assert.assertEquals("Shipment for the given id is not found", e.getMessage());
		}


	}


}

