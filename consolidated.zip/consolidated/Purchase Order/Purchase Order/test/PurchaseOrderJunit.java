import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


public class PurchaseOrderJunit {
	PurchaseOrderBO purchaseOrderBO;
	SimpleDateFormat date;
	@Rule
	public ExpectedException exception = ExpectedException.none();
	@Before
	public void init(){
		purchaseOrderBO = new PurchaseOrderBO();
		date = new SimpleDateFormat("dd-mm-yyyy");
	}
	@Test
	public void testInsufficientQuantityException() throws ParseException {
		List<Item> itemlist = new ArrayList<Item>();
		itemlist.add(new Item((long)1,"Voltas 1.4 Ton 3",10,27900.00));
		itemlist.add(new Item((long)2,"Onida 1.5 Ton 3 Star",20,32490.00));
		try {
			purchaseOrderBO.createPurchaseOrder(itemlist, new Integer[] {15,5}, "xyz", "6654412255",date.parse("27-05-2018"));
			fail();
		} catch (InsufficientQuantityException e) {
			assertEquals("InsufficientQuantityException: Item Voltas 1.4 Ton 3 is unavailable",e.toString());
		}
	}
	@Test
	public void testCreatePurchaseOrder() throws ParseException {
		List<Item> itemlist = new ArrayList<Item>();
		itemlist.add(new Item((long)1,"Voltas 1.4 Ton 3",10,27900.00));
		itemlist.add(new Item((long)2,"Onida 1.5 Ton 3 Star",20,32490.00));
		try {
			purchaseOrderBO.createPurchaseOrder(itemlist, new Integer[] {5,6}, "xyz", "6654412255",date.parse("27-05-2018"));
		} catch (InsufficientQuantityException e) {
			e.printStackTrace();
		}
		//List<PurchaseOrder> purchaseOrders= purchaseOrderBO.getAllPurchaseOrder();
		//assertThat(purchaseOrders,contains(hasProperty("customerName",is("xyz"))));
	}
	@Test
	public void testRemoveItem() throws InsufficientQuantityException, ParseException {
		ItemDAO it = new ItemDAO();
		List<Item> test = new ArrayList<Item>();
		test.add(it.getItemById((long)1));
		test.add(it.getItemById((long)2));
		Integer[] t = {2,3};
		purchaseOrderBO.createPurchaseOrder(test,t,"Test", "90035380", date.parse("2016-09-09"));
		purchaseOrderBO.removeItemFromPurchaseOrder((long)1);
		//List<PurchaseOrder> purchaseOrders= purchaseOrderBO.getAllPurchaseOrder();
		//assertFalse(purchaseOrders.contains(hasProperty("customerName",is("Test"))));
	}
	
}
