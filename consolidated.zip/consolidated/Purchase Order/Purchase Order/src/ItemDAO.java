import java.util.*;

public class ItemDAO {
	
	public static List<Item> itemList;

	static {
		itemList = new ArrayList<Item>();
		itemList.add(new Item((long)1,"Voltas 1.4 Ton 3",10,27900.00));
		itemList.add(new Item((long)2,"Onida 1.5 Ton 3 Star",20,32490.00));
		itemList.add(new Item((long)3,"Micromax Split AC",30,25000.00));
		itemList.add(new Item((long)4,"Kenstar 1.5 Ton 5",20,26990.00));
		itemList.add(new Item((long)5,"LG 1 Ton Inverter AC",20,27900.00));
		itemList.add(new Item((long)6,"Moto G Play",10,7999.00));
	}
	
    public List<Item> getAllItems() {
        return itemList;
    }
   
    public Item getItemById(Long itemId) {
    	int i;
    	for(i=0;i<itemList.size();i++)
    		if(itemList.get(i).getId() == itemId)
    			break;
    	return itemList.get(i);
    }
}