import java.util.ArrayList;
import java.util.List;

public class PurchaseOrderDAO {
	
	static List<PurchaseOrder> purchaseOrderList;
	
	static {
		purchaseOrderList = new ArrayList<PurchaseOrder>();
	}
	
    public void createPurchaseOrder(PurchaseOrder po) {
        purchaseOrderList.add(po);
    }
    
    public List<PurchaseOrder> getAllPurchaseOrder() {
        return purchaseOrderList;
    }
    
    
}