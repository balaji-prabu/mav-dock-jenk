import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PurchaseOrderBO {


    public Long createPurchaseOrder(List<Item> items, Integer[] quantity,String customerName,String mobileNumber,Date orderDate) throws InsufficientQuantityException {
   
    List<OrderLine> lines = new ArrayList<OrderLine>();
    double totalAmount = 0;
   
    for(int count=0; count<items.size();count++)
    {
   
    if(quantity[count] > items.get(count).getAvailableQuantity())
    {
    throw new InsufficientQuantityException("Item "+items.get(count).getName()+" is unavailable");
   
    }
   
    totalAmount = totalAmount+items.get(count).getPrice();
   
    Item item = new Item();
    item.setName(items.get(count).getName());
    item.setId(items.get(count).getId());
    item.setAvailableQuantity(items.get(count).getAvailableQuantity());
    item.setPrice(items.get(count).getPrice());
    OrderLine line = new OrderLine();
    //line.setId(id);
    line.setItem(item);
    line.setPrice(items.get(count).getPrice());
    line.setPurchaseOrder(null);
    line.setQuantity(quantity[count]);
   
    lines.add(line);
   
   
    }
   
   
    PurchaseOrder order = new PurchaseOrder();
order.setCustomerName(customerName);
order.setCreatedDate(new Date());
//order.setId(id);
order.setMobileNumber(mobileNumber);
order.setNumberOfItems(items.size());
order.setOrderDate(orderDate);
order.setOrderLineList(lines);
order.setTotalAmount(totalAmount);
PurchaseOrderDAO purchaseOrderDao = new PurchaseOrderDAO();
long id = purchaseOrderDao.createPurchaseOrder(order);
    return id;
        

        
    }
    
}