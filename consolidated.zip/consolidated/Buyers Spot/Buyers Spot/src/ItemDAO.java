import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO implements IItemDAO{

    public List<Item> getAllItems() {
    List<Item> items = new ArrayList<Item>();
   
    try {
Connection connect = DBUtils.getConnection();
PreparedStatement stmt = connect.prepareStatement("select * from item");
ResultSet result = stmt.executeQuery();
while(result.next())
{
Item item = new Item();
item.setId(result.getLong("id"));
item.setAvailableQuantity(result.getInt("available_quantity"));
item.setName(result.getString("name"));
item.setPrice(result.getDouble("price"));
items.add(item);
}
return items;
} catch (InstantiationException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (IllegalAccessException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
   
   
    return items;
        
    }
    
    
    
    public Item getItemById(Long itemId) {

    Item item = null;
    try {
    Connection connect = DBUtils.getConnection();
PreparedStatement stmt = connect.prepareStatement("select * from item where id=?");
stmt.setLong(1, itemId);
ResultSet result = stmt.executeQuery();
   
while(result.next()){
item = new Item();
item.setId(result.getLong("id"));
item.setAvailableQuantity(result.getInt("available_quantity"));
item.setName(result.getString("name"));
item.setPrice(result.getDouble("price"));
}
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (InstantiationException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (IllegalAccessException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
    
   
    return item;
    }
    
   
}