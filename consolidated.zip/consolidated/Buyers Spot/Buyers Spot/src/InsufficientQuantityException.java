public class InsufficientQuantityException extends Exception{
 // fill the code
private static final long serialVersionUID = 1L;
InsufficientQuantityException(String message){
super(message);
}
}