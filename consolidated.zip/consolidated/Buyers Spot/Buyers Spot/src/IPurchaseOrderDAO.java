
import java.util.List;

public interface  IPurchaseOrderDAO{
public Long  createPurchaseOrder(PurchaseOrder purchaseOrderObj);
}