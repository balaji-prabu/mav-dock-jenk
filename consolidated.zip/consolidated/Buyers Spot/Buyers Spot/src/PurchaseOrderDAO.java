import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;




public class PurchaseOrderDAO implements IPurchaseOrderDAO //fill the code
{

    public Long createPurchaseOrder(PurchaseOrder purchaseOrderobj) {
        
   Long pod=null;
    ResultSet purchaseOrderGeneratedKeys = null;
    try {
Connection conn = DBUtils.getConnection();
Statement stmt=conn.createStatement();
String itemQuery = "insert into item(name,available_quantity,price) values (?,?,?)";
String orderLineQuery = "insert into order_line(price,quantity ,item_id,purchase_order_id) values (?,?,?,?)";
String purchaseOrderQuery = "insert into purchase_order(order_date,created_date,number_of_items,total_amount,customer_name,mobile_number) values (?,?,?,?,?,?)";
PreparedStatement  itemStmt = conn.prepareStatement(itemQuery);
PreparedStatement  orderStmt = conn.prepareStatement(orderLineQuery);
PreparedStatement  purchaseOrderStmt = conn.prepareStatement(purchaseOrderQuery);
purchaseOrderStmt.setDate(1, new Date(new java.util.Date().getTime()));
purchaseOrderStmt.setDate(2, new java.sql.Date(purchaseOrderobj.getOrderDate().getTime()));
purchaseOrderStmt.setInt(3, purchaseOrderobj.getNumberOfItems());
purchaseOrderStmt.setDouble(4, purchaseOrderobj.getTotalAmount());
purchaseOrderStmt.setString(5, purchaseOrderobj.getCustomerName());
purchaseOrderStmt.setString(6, purchaseOrderobj.getMobileNumber());
purchaseOrderStmt.execute();
purchaseOrderGeneratedKeys = purchaseOrderStmt.getGeneratedKeys();
purchaseOrderGeneratedKeys.next();
long purchaseOrderId = purchaseOrderGeneratedKeys.getLong(1);
List<OrderLine> list = purchaseOrderobj.getOrderLineList();
for(int cnt=0; cnt<list.size();cnt++)
{
Item itm = list.get(cnt).getItem();
itemStmt.setString(1, itm.getName());
itemStmt.setInt(2, itm.getAvailableQuantity());
int qty=itm.getAvailableQuantity()-list.get(cnt).getQuantity();
itemStmt.setDouble(3, itm.getPrice());
//boolean itemResult = itemStmt.execute();
String sel="select id from item where name='"+itm.getName()+"'";
ResultSet oderResult = conn.createStatement().executeQuery(sel);
oderResult.next();
String upd="update item set available_quantity="+qty+" where name='"+itm.getName()+"'" ;
stmt.executeUpdate(upd);

orderStmt.setDouble(1, list.get(cnt).getPrice());
orderStmt.setInt(2, list.get(cnt).getQuantity());
//oderResult.next();
orderStmt.setInt(3, oderResult.getInt("id"));
orderStmt.setInt(4, (int) purchaseOrderId);
orderStmt.execute();
}
pod=purchaseOrderId;
return purchaseOrderId;
} catch (InstantiationException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (IllegalAccessException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

   
    return pod;
    }
}
