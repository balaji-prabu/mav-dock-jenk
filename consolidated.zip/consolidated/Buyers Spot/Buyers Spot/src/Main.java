import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class Main {

    public static void main(String args[]) throws IOException, ParseException {
        
        PurchaseOrderBO purchaseOrderBO = new PurchaseOrderBO();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        ItemBO itemBO = new ItemBO();
        //fill the code
        List<Item> itemList = itemBO.getAllItems();
        System.out.println(String.format("%-15s %-25s %-25s %-15s","Item ID","Name","Available Quantity","Price"));
        for(int count=0;count<itemList.size();count++)
        {
        System.out.println(String.format("%-15s %-25s %-25s %-15s",itemList.get(count).getId(),itemList.get(count).getName(),itemList.get(count).getAvailableQuantity(),itemList.get(count).getPrice()));
        }
        System.out.println("Creating new purchase order...");
        
        System.out.println("Enter Customer Name:");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String customerName = reader.readLine();
        System.out.println("Enter Contact Number:");
        String mobile = reader.readLine();
        System.out.println("Enter Order Date(yyyy-MM-dd):");
        Date orderDate = sdf.parse(reader.readLine());
        System.out.println("Enter all the Item ID you want to purchase:");
        String[] itemStr = reader.readLine().split(",");
        System.out.println("Enter number of quantities:");
        String[] quantitiesStr = reader.readLine().split(",");
        
        Integer[] quantity = new Integer[quantitiesStr.length];
        for(int count=0;count<quantitiesStr.length;count++)
        {
        quantity[count] = Integer.parseInt(quantitiesStr[count]);
        }
        
        List<Item> list = new ArrayList<Item>();
        for(int count=0;count<itemStr.length;count++)
        {
        Item item =new Item();
        item.setId(Long.parseLong(itemStr[count]));
        int quantity1 = 0;
        double price = 0;
        for(int count1=0;count1<itemList.size();count1++)
            {
        long id1 =  itemList.get(count1).getId();
        if(id1 == Long.parseLong(itemStr[count]))
        {
        item.setName(itemList.get(count1).getName());
        quantity1=itemList.get(count1).getAvailableQuantity();
        price = itemList.get(count1).getPrice();
        }
            }
       
        item.setAvailableQuantity(quantity1);
        item.setPrice(price);
       
        list.add(item);
        }
        
        PurchaseOrderBO purchaseOrder = new PurchaseOrderBO();
        
        
        Long createdId=0l;
try {
createdId = purchaseOrder.createPurchaseOrder(list, quantity, customerName, mobile, orderDate);
System.out.println("Order placed with id "+createdId);
} catch (InsufficientQuantityException e) {
// TODO Auto-generated catch block
System.out.println(e.getMessage());
}
        
         // fill the code
            
   
    }
    
}
