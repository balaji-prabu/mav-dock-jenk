import java.util.List;

public interface IItemDAO{
public List<Item> getAllItems();
}