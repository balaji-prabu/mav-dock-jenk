import java.util.List;

public class ItemBO {
public List<Item> getAllItems() {
IItemDAO itemdao = new ItemDAO();
return itemdao.getAllItems();
}
public Item getItemById(Long itemId) {
ItemDAO itemdao = new ItemDAO();
return itemdao.getItemById(itemId);
}
}