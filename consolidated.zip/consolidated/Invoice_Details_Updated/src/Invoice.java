

public class Invoice {
	Integer id;
	String customerName;
	String invoiceNumber;
	Double amount;
	Double totalAmount;
	
	public Invoice(){}
	public Invoice(Integer id, String customerName, String invoiceNumber,
			Double amount,Double totalAmount){
		this.id = id;
		this.customerName = customerName;
		this.invoiceNumber = invoiceNumber;
		this.amount = amount;
		this.totalAmount = totalAmount ;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
		
	
}
