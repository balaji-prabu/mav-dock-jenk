import java.sql.SQLException;
import java.util.List;
import java.io.*;
public class Main {

	public static void main(String agrs[]) throws IOException,InvalidInvoiceNumberException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Integer invoiceId,vat,cst,travel;
		SalesInvoiceBO salesInvoiceBO = new SalesInvoiceBO();	
		ServiceInvoiceBO serviceInvoiceBO = new ServiceInvoiceBO();

		System.out.println("1).Sales Tax");
		System.out.println("2).Service Tax");		
		Integer ch = Integer.parseInt(br.readLine());
		if(ch==1){
			List<SalesInvoice> salesList = salesInvoiceBO.listSalesInvoice();
			System.out.format("%s %8s %8s %8s\n","Id","VatTax","CstTax","Invoice Number");
			for(SalesInvoice salesListIns:salesList){
				System.out.format("%s %7s %7s %7s\n",salesListIns.getId(),salesListIns.getVatTaxPercentage(),salesListIns.getCstTaxPercentage(),salesListIns.getInvoiceNumber());		     		 
			}	 		 
			System.out.println("Enter the invoice number");
			String salesInvoiceNumber = br.readLine();		
			//fill the code
			boolean flag = false;
			//for(SalesInvoice salesListIns:salesList){
			//String invoicenumber = salesListIns.getInvoiceNumber();
			String[] invoicNumber1 = salesInvoiceNumber.split("-");
			if((invoicNumber1[0].contains("INV"))&&(invoicNumber1[1].matches("[0-9]+"))&&(invoicNumber1[2].matches("[A-Z]+"))){
				for(SalesInvoice salesListIns:salesList){
					if(salesListIns.getInvoiceNumber().equals(salesInvoiceNumber)){
						flag = true;
					}
				}
			}
			if(flag==false)
			{
				try{
					throw new InvalidInvoiceNumberException("Invalid invoice number");
				}
				catch(InvalidInvoiceNumberException e){
					System.out.println(e);
				}

			}

			else{

				System.out.println("Enter the vat tax");
				vat = Integer.parseInt(br.readLine());
				System.out.println("Enter the cst tax");
				cst = Integer.parseInt(br.readLine());
				//fill the code 
				SalesInvoice salesinvoice;		
				salesinvoice = salesInvoiceBO.getSalesInvoice(salesInvoiceNumber);
				salesinvoice.setVatTaxPercentage(vat);
				salesinvoice.setCstTaxPercentage(cst);
				salesInvoiceBO.updateTaxPercentage(salesinvoice);
				Double totalAmount = salesinvoice.computeTax();					
				System.out.println("TotalAmount "+totalAmount);
			}
		}

		else{
			List<ServiceInvoice> serviceList = serviceInvoiceBO.listServiceInvoice();	
			System.out.format("%s %7s %7s\n","Id","TravelTax","Invoice Number");
			for(ServiceInvoice serviceListIns:serviceList){
				System.out.format("%s %7s %7s\n",serviceListIns.getId(),serviceListIns.getTravelTaxPercentage(),serviceListIns.getInvoiceNumber());
			} 		 

			System.out.println("Enter the invoice number");
			String serviceInvoiceNumber = br.readLine();	
			//fill the code	
			boolean flag = false;
			String[] invoicNumber1 = serviceInvoiceNumber.split("-");
			if((invoicNumber1[0].contains("INV"))&&(invoicNumber1[1].matches("[0-9]+"))&&(invoicNumber1[2].matches("[A-Z]+"))){
				for(ServiceInvoice serviceListIns:serviceList){
					if(serviceListIns.getInvoiceNumber().equals(serviceInvoiceNumber)){
						flag = true;
					}
				}
			}
			if(flag==false)
			{
				try{
					throw new InvalidInvoiceNumberException("Invalid invoice number");
				}
				catch(InvalidInvoiceNumberException e){
					System.out.println(e);
				}
			}else{
				System.out.println("Enter the travel tax");
				travel = Integer.parseInt(br.readLine());
				//fill the code
				ServiceInvoice serviceinvoice;		
				serviceinvoice = serviceInvoiceBO.getServiceInvoice(serviceInvoiceNumber);
				serviceinvoice.setTravelTaxPercentage(travel);
				serviceInvoiceBO.updateTaxPercentage(serviceinvoice);
				Double totalAmount = serviceinvoice.computeTax();
				System.out.println("TotalAmount "+totalAmount);
			}

		}

	}
}
