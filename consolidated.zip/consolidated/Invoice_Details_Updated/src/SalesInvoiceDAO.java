import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class SalesInvoiceDAO {
	
    public List<SalesInvoice> listSalesInvoiceDetails() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
      //fill your code
    	Statement stmt = DBConnection.getConnection().createStatement();
    	ResultSet rs = stmt.executeQuery("select s.id, i.customer_name, i.invoice_number, i.amount, i.total_amount, s.vat_Tax_Percentage, s.cst_Tax_Percentage from invoice i, sales_invoice s where i.id = s.id");
    	List<SalesInvoice> salesinvoicelist = new ArrayList<SalesInvoice>();
    	while(rs.next()){
    		salesinvoicelist.add(new SalesInvoice(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getDouble(4),
    				rs.getDouble(5),rs.getInt(6),rs.getInt(7)));
    	}
    	return salesinvoicelist;
    }

   public SalesInvoice getSalesInvoice(String salesInvoiceNumber) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
     //fill your code  	   
	   Statement stmt = DBConnection.getConnection().createStatement();
	   String sql = String.format("select * from invoice where invoice_number='%s'", salesInvoiceNumber);
   		ResultSet rs = stmt.executeQuery(sql);
   		rs.next();
   		SalesInvoice invoicedetails = new SalesInvoice();
   		invoicedetails.setId(rs.getInt(1));
   		invoicedetails.setCustomerName(rs.getString(2));
   		invoicedetails.setInvoiceNumber(rs.getString(3));
   		invoicedetails.setAmount(rs.getDouble(4));
   		invoicedetails.setTotalAmount(rs.getDouble(5));
   		return invoicedetails;
   }   
   
   public void updateTaxPercentage(SalesInvoice salesInvoice) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
      //fill your code	   
	   Statement stmt = DBConnection.getConnection().createStatement();
	   String sql = String.format("Update sales_invoice SET vat_Tax_Percentage=%s, cst_Tax_Percentage = %s where id = %s", salesInvoice.getVatTaxPercentage(), salesInvoice.getCstTaxPercentage(), salesInvoice.getId()); 
	   stmt.executeUpdate(sql);
   }
   
   
}
