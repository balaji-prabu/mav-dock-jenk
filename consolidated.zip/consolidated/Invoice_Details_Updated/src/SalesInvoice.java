public class SalesInvoice extends Invoice{

   Integer vatTaxPercentage;
   Integer cstTaxPercentage;
	
   public SalesInvoice(){
	   super();
   }
   public SalesInvoice(Integer id, String customerName, String invoiceNumber,
			Double amount,Double balanceAmount,Integer vatTaxPercentage,Integer cstTaxPercentage) {
	super(id,customerName,invoiceNumber,amount,balanceAmount);
	this.vatTaxPercentage = vatTaxPercentage;
	this.cstTaxPercentage = cstTaxPercentage;
   }

   public Integer getVatTaxPercentage() {
	return vatTaxPercentage;
   }


   public void setVatTaxPercentage(Integer vatTaxPercentage) {
	this.vatTaxPercentage = vatTaxPercentage;
	
   }  


   public Integer getCstTaxPercentage() {
	return cstTaxPercentage;
   }


   public void setCstTaxPercentage(Integer cstTaxPercentage) {
	this.cstTaxPercentage = cstTaxPercentage;
   }


   public Double computeTax(){
     //fill your code
	  return  amount+((amount*vatTaxPercentage)/100)+((amount*cstTaxPercentage)/100);	   
   }
	
	
}
