import java.sql.SQLException;
import java.util.List;


public class ServiceInvoiceBO {
	ServiceInvoiceDAO serviceinvoicedao = new ServiceInvoiceDAO();
	  public void updateTaxPercentage(ServiceInvoice serviceInvoice) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
	      //fill your code
		  serviceinvoicedao.updateTaxPercentage(serviceInvoice);
	   }
          public List<ServiceInvoice> listServiceInvoice() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
           //fill your code
        	  return serviceinvoicedao.listServiceInvoiceDetails();
           }
          public ServiceInvoice getServiceInvoice(String serviceInvoiceNumber) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
           //fill your code
        	  return serviceinvoicedao.getServiceInvoice(serviceInvoiceNumber);
           }
}
