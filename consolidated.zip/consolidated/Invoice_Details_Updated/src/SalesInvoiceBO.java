import java.sql.SQLException;
import java.util.List;


public class SalesInvoiceBO {
	SalesInvoiceDAO salesinvoicedao = new SalesInvoiceDAO();
	
	public void updateTaxPercentage(SalesInvoice salesInvoice) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		//fill your code
		salesinvoicedao.updateTaxPercentage(salesInvoice);
	}

	public List<SalesInvoice> listSalesInvoice() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		//fill your code
		return salesinvoicedao.listSalesInvoiceDetails();
	}

	public SalesInvoice getSalesInvoice(String SalesInvoiceNumber) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, InvalidInvoiceNumberException{
		//fill your code
		return salesinvoicedao.getSalesInvoice(SalesInvoiceNumber);
	}
}
