public class InvalidInvoiceNumberException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidInvoiceNumberException(String s){  
		  super(s);  
		 }  
		
}
