DROP DATABASE IF EXISTS invoice;
CREATE DATABASE invoice;
USE invoice;

DROP TABLE IF EXISTS invoice;
DROP TABLE IF EXISTS sales_invoice;
DROP TABLE IF EXISTS service_invoice;

CREATE TABLE invoice (
  id int(11) NOT NULL AUTO_INCREMENT,
  customer_name varchar(20) DEFAULT NULL,
  invoice_number varchar(20) DEFAULT NULL,
  amount double DEFAULT NULL,
  total_amount double DEFAULT NULL,
  PRIMARY KEY (id)
);



CREATE TABLE sales_invoice (
  id int(11) NOT NULL,
  vat_Tax_Percentage int(11) DEFAULT NULL,
  cst_Tax_Percentage int(11) DEFAULT NULL,
  PRIMARY KEY (id)
) ;

CREATE TABLE service_invoice (
  id int(11) NOT NULL,
  travel_Tax_Percentage int(11) DEFAULT NULL,
  PRIMARY KEY (id)
) ;


INSERT INTO invoice VALUES(1,'Devi','INV-23456-IND',1000,2000),(2,'Jones','INV-87123-WI',4000,8000),(3,'James','INV-98765-IND',2500,3450),(4,'Emily','INV-87654-PAK',8976,9980),(5,'Kevin','INV-09812-SA',7656,8876);
INSERT INTO sales_invoice VALUES(1,2,5),(2,2,5);
INSERT INTO service_invoice VALUES(3,3),(4,3),(5,3);
