
public class ServiceInvoice extends Invoice {
	
	Integer travelTaxPercentage;
	
	ServiceInvoice(){
		super();
	}
	ServiceInvoice(Integer id, String customerName, String invoiceNumber,
			Double amount,Double balanceAmount,Integer travelTaxPercentage){
	super(id,customerName,invoiceNumber,amount,balanceAmount);
        this.travelTaxPercentage = travelTaxPercentage;
	}
	
	public Integer getTravelTaxPercentage() {
		return travelTaxPercentage;
	}


	public void setTravelTaxPercentage(Integer travelTaxPercentage) {
		this.travelTaxPercentage = travelTaxPercentage;
	}


	 public Double computeTax(){
	   //fill your code	
		 return  amount+((amount*travelTaxPercentage)/100);
	 }
			
	
}
