import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class ServiceInvoiceDAO {
	
    public List<ServiceInvoice> listServiceInvoiceDetails() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
     //fill your code
    	Statement stmt = DBConnection.getConnection().createStatement();
    	ResultSet rs = stmt.executeQuery("select s.id, i.customer_name, i.invoice_number, i.amount, i.total_amount, s.travel_Tax_Percentage from invoice i, service_invoice s where i.id = s.id");
    	List<ServiceInvoice> serviceinvoicelist = new ArrayList<ServiceInvoice>();
    	while(rs.next()){
    		serviceinvoicelist.add(new ServiceInvoice(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getDouble(4),
    				rs.getDouble(5),rs.getInt(6)));
    	}
    	return serviceinvoicelist;
    }

   public ServiceInvoice getServiceInvoice(String serviceInvoiceNumber) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
     //fill your code	   	   
	   Statement stmt = DBConnection.getConnection().createStatement();
	   String sql = String.format("select * from invoice where invoice_number='%s'", serviceInvoiceNumber);
   		ResultSet rs = stmt.executeQuery(sql);
   		rs.next();
   		ServiceInvoice serviceinvoicedetails = new ServiceInvoice();
   		serviceinvoicedetails.setId(rs.getInt(1));
   		serviceinvoicedetails.setCustomerName(rs.getString(2));
   		serviceinvoicedetails.setInvoiceNumber(rs.getString(3));
   		serviceinvoicedetails.setAmount(rs.getDouble(4));
   		serviceinvoicedetails.setTotalAmount(rs.getDouble(5));
   		return serviceinvoicedetails;
	   
   }   
   public void updateTaxPercentage(ServiceInvoice serviceInvoice) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
       //fill your code	
	   Statement stmt = DBConnection.getConnection().createStatement();
	   String sql = String.format("Update service_invoice SET travel_Tax_Percentage = %s where id = %s",serviceInvoice.getTravelTaxPercentage(),serviceInvoice.getId() ); 
	   stmt.executeUpdate(sql);
   }
   
   
}
